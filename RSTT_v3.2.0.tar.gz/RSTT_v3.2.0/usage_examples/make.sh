#!/bin/bash


#---- Configuration ------------------------------------------------------------

# absolute path to folder containing RSTT libraries
RSTT_ROOT=${RSTT_ROOT:-${RSTT_HOME:-${SLBM_ROOT:-${SLBM_HOME:-$PWD/..}}}}
LIBDIR=$RSTT_ROOT/lib


#---- Explanation of some common compiling parameters --------------------------

# -D<arch>
# Defines a symbol for the preprocessor which may adjust some code for different
# operating systems.

# -m<32|64>
# Tells the compiler whether we're on a 32 or 64-bit system.

# -O<1-3>
# Optimize the code, which makes compilation take longer but improves runtime
# performance and filesize. Level 3 (-O3) is the maximum, but newer version of
# gcc don't recommend above level 2 (-O2), and RSTT seems to throw some
# compilation errors when level 2 is used.

# -I
# Include directories for various headers.

# -L
# Location of the libraries (*.so or *.dylib) that we load with "-l" commands.

# -Wl
# Defines some parameters for the linker.

# -Wl,-rpath,<path>
# Tells the linker to search the <path> for linked libraries at runtime. In this
# shell script, we are pointing to the absolute path of the directory containing
# the RSTT library files ($LIBDIR); however, we could also specify relative
# paths by using "$$ORIGIN" on Linux or "@executable_path" on MacOS to mean
# "the directory containing the application executable". For example,
# -Wl,-rpath,'$$ORIGIN/../lib'


#---- C++ compile --------------------------------------------------------------

compile_cpp() {

    # MacOS
    if [ "$(uname -s)" == "Darwin" ]; then

        (
            set -x  # echo commands
            g++ -march=native -Ddarwin -m64 -O1 -I../GeoTessCPP/include -I../SLBM/include -o cpp_example.o -c cpp_example.cc
            g++ -march=native -Ddarwin -m64 -O1 -Wl,-rpath,"$LIBDIR" -o cpp_example cpp_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm
        )

    else  #linux

        (
            set -x  # echo commands
            g++ -march=native -Dlinux -m64 -O1 -I../GeoTessCPP/include -I../SLBM/include -o cpp_example.o -c cpp_example.cc
            g++ -march=native -Dlinux -m64 -O1 -Wl,-rpath,"$LIBDIR" -o cpp_example cpp_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm
        )

    fi

    # clean up
    rm cpp_example.o

}


#---- C compile ----------------------------------------------------------------

compile_c() {

    # MacOS
    if [ "$(uname -s)" == "Darwin" ]; then

        (
            set -x  # echo commands
            gcc -march=native -Ddarwin -m64 -O1 -I../GeoTessCPP/include -I../SLBM_C_shell/include -o c_example.o -c c_example.c
            gcc -march=native -Ddarwin -m64 -O1 -Wl,-rpath,"$LIBDIR" -o c_example c_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm -lslbmCshell
        )

    else  # linux

        (
            set -x  # echo commands
            gcc -march=native -Dlinux -m64 -O1 -I../GeoTessCPP/include -I../SLBM/include -I../SLBM_C_shell/include -o c_example.o -c c_example.c
            gcc -march=native -Dlinux -m64 -O1 -Wl,-rpath,"$LIBDIR" -o c_example c_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm -lslbmCshell
        )

    fi

    # clean up
    rm c_example.o

}


#---- Fortran compile ----------------------------------------------------------

compile_fortran() {

    # MacOS
    if [ "$(uname -s)" == "Darwin" ]; then

        (
            set -x  # echo commands
            gfortran -march=native -Ddarwin -m64 -O1 -fno-underscoring -cpp -ffree-line-length-none -I../GeoTessCPP/include -I../SLBM/include -I../SLBM_Fort_shell/include -o fortran_example.o -c fortran_example.f90
            gfortran -march=native -Ddarwin -m64 -O1 -fno-underscoring -cpp -ffree-line-length-none -Wl,-rpath,"$LIBDIR" -o fortran_example fortran_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm -lslbmFshell
        )

    else #linux

        (
            set -x  # echo commands
            gfortran -march=native -Dlinux -m64 -O1 -fno-underscoring -cpp -ffree-line-length-none -I../GeoTessCPP/include -I../SLBM/include -I../SLBM_Fort_shell/include -o fortran_example.o -c fortran_example.f90
            gfortran -march=native -Dlinux -m64 -O1 -fno-underscoring -cpp -ffree-line-length-none -Wl,-rpath,"$LIBDIR" -o fortran_example fortran_example.o -lm -lstdc++ -L"$LIBDIR" -lgeotesscpp -lslbm -lslbmFshell
        )

    fi

    # clean up
    rm fortran_example.o constants.mod error_checking.mod

}


#---- Java compile -------------------------------------------------------------

compile_java() {

    # compile java code
    (
        set -x  # echo commands
        javac -cp "$LIBDIR/slbmjni.jar" java_example.java
    )

}


#---- run code -----------------------------------------------------------------

run_cpp() {
    (
        set -x  # echo commands
        ./cpp_example
    )
}

run_c() {
    (
        set -x  # echo commands
        ./c_example
    )
}

run_fortran() {
    (
        set -x  # echo commands
        ./fortran_example
    )
}

run_java() {
    (
        set -x  # echo commands
        java -Djava.library.path="$LIBDIR" -cp .:"$LIBDIR/slbmjni.jar" java_example
    )
}

run_python() {
    (
        set -x  # echo commands
        RSTT_ROOT=$RSTT_ROOT ./python_example.py
    )
}


#---- main ---------------------------------------------------------------------

# if no arguments are given
if [ $# -eq 0 ]; then

    # show usage example
    echo "Usage: $0 [ all | cpp | c | fortran | java | python ]"
    exit

fi

# if arguments are given, loop through them
while [ $# -gt 0 ]; do

    # turn off case matching of `case` statements
    shopt -s nocasematch

    # check the current argument 
    case "${1}" in

        cpp|cc|c++)
            compile_cpp && run_cpp
            ;;

        c)
            compile_c && run_c
            ;;

        fortran)
            compile_fortran && run_fortran
            ;;

        java)
            compile_java && run_java
            ;;

        python)
            run_python
            ;;

        all)
            compile_cpp     && run_cpp
            compile_c       && run_c
            compile_fortran && run_fortran
            compile_java    && run_java
            run_python
            ;;

        *)
            echo "Usage: $0 [ all | cpp | c | fortran | java | python ]"
            exit
            ;;

    esac

    # remove the current argument from the stack and move onto the next one
    shift

done
