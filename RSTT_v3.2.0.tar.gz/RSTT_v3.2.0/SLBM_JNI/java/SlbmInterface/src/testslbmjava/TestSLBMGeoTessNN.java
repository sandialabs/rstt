package testslbmjava;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import gov.sandia.gnem.slbmjni.GridProfile;
import gov.sandia.gnem.slbmjni.GridWeight;
import gov.sandia.gnem.slbmjni.SLBMException;
import gov.sandia.gnem.slbmjni.SlbmInterface;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.BeforeClass;
import org.junit.Test;

public class TestSLBMGeoTessNN
{
    private static SlbmInterface slbm;

    private static int verbosity = 1;

    private static final double dtr = 3.1415926535897932384626 / 180.;
    private static final double rtd = 180. / 3.1415926535897932384626;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception
    {
        File here = new File(".");
        System.out.println("Running from directory "+here.getCanonicalPath());

        System.out.println("If running from within Eclipse be sure the set the DYLD_LIBRARY_PATH "
                + "environment variable in the Run Configuration\n");

        System.out.println("Run this test suite from the SLBM_Root directory.\n");

        // Load the c++ SLBM library libslbm.so into memory.
        System.loadLibrary("slbmjni");
        System.out.println("setUpBeforeClass()  slbmjni loaded");
        slbm = new SlbmInterface();

        System.out.println("SlbmInterface version " + slbm.getVersion());

        slbm.loadVelocityModel("models/rstt.2.3_geotess");
        System.out.println("\nVelocity model loaded.");

        createGreatCircle(slbm, "Pn");
        slbm.initializeActiveNodes(28 * dtr, 80 * dtr, 32 * dtr, 105 * dtr);
    }

    private static boolean createGreatCircle(SlbmInterface slbm, String phase)
    {
        double rlat = 30. * dtr;
        double rlon = 90. * dtr;
        double rdepth = -1;
        double slat = 35. * dtr;
        double slon = 95. * dtr;
        double sdepth = 0.;

        try
        {
            slbm.createGreatCircle(phase, slat, slon, sdepth, rlat, rlon,
                    rdepth);
            return true;
        }
        catch (SLBMException e)
        {
            e.printStackTrace();
        }
        return false;
    }

    @Test
    public void testGetVersion()
    {
        if (verbosity > 0)
            System.out.println("testGetVersion()");
        assert (slbm.getVersion().equals("3.2.0"));
    }

    // @Test
    public void testSaveVelocityModel() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testSaveVelocityModel()");
        slbm.saveVelocityModel("testmodel.ascii");
    }

    @Test
    public void testLoadVelocityModelBinary()
    {
        if (verbosity > 0)
            System.out.println("testLoadVelocityModelBinary()");

        // TODO

    }

    @Test
    public void testSpecifyOutputDirectory()
    {
        if (verbosity > 0)
            System.out.println("testSpecifyOutputDirectory()");

        // TODO

    }

    @Test
    public void testSaveVelocityModelBinary()
    {
        if (verbosity > 0)
            System.out.println("testSaveVelocityModelBinary()");

        // TODO

    }

    @Test
    public void testGetTessId()
    {
        if (verbosity > 0)
            System.out.println("testGetTessId()");

        // TODO

    }

    @Test
    public void testInitializeActiveNodes()
    {
        if (verbosity > 0)
            System.out.println("testInitializeActiveNodes()");
        slbm.initializeActiveNodes(28 * dtr, 80 * dtr, 32 * dtr, 105 * dtr);
        assertEquals(147, slbm.getNActiveNodes());
    }

    @Test
    public void testCreateGreatCircle() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testCreateGreatCircle()");

        if (!createGreatCircle(slbm, "Pn"))
            fail("\ntestCreateGreatCircle() failed\n\n");
    }

    // @Test
    public void testClear()
    {
        if (verbosity > 0)
            System.out.println("testClear()");
        slbm.clear();
        try
        {
            slbm.getTravelTime();
            fail("\ntestClear() failed\n\n");
        }
        catch (SLBMException ex)
        {
        }
        createGreatCircle(slbm, "Pn");
    }

    @Test
    public void testToStringInt() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testToStringInt()");

        // depends on active nodes being set as follows:
        // slbm.initializeActiveNodes(28*dtr, 80*dtr, 32*dtr, 105*dtr);

        ArrayList<String> actual = getRecords(slbm.toString(6), false);

        ArrayList<String> expected = new ArrayList<String>(259);
        expected.add("");
        expected.add("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        expected.add("Great Circle ");
        expected.add("");
        expected.add("   RSTT Version 3.2.0");
        expected.add("");
        expected.add("   Solution method = GreatCircle_Xn::computeTravelTimeCrust()");
        expected.add("");
        expected.add("   Earth radius varies as a function of latitude. ");
        expected.add("");
        expected.add("   Maximum allowed source-receiver separation = 15.0000 degrees.");
        expected.add("   Maximum allowed source depth = 200.0000 km.");
        expected.add("");
        expected.add("   Phase = Pn");
        expected.add("                    X, deg  X,moho, km      T, sec");
        expected.add("   Source   =       0.8370     92.1119     17.3262");
        expected.add("   Receiver =       0.9018     99.1803     18.8230");
        expected.add("   Moho     =       4.7943    527.1554     65.1888");
        expected.add("   Gamma    =                              -0.0907");
        expected.add("   Total    =       6.5331    718.4476    101.2473");
        expected.add("");
        expected.add("   Average mantle velocity  =       8.1046");
        expected.add("   Path average velocity    =       8.0868");
        expected.add("   Path average gradient    =   0.00152675");
        expected.add("   C                        =   0.00034702");
        expected.add("   H                        =      12.0435");
        expected.add("   C*H                      =       0.0042");
        expected.add("   chMax                    =       0.2000");
        expected.add("   Average Moho depth       =      68.3486");
        expected.add("   Turning depth            =    6291.5908");
        expected.add("   Ray parameter            =     776.2425");
        expected.add("   Fraction Active          =       0.5455");
        expected.add("");
        expected.add("");
        expected.add("   Source Profile:");
        expected.add("");
        expected.add("                   Lat      Lon    Depth  R Earth        P   P crit");
        expected.add("   Location:   35.0000  95.0000    0.000  6371.14   776.24   781.23");
        expected.add("   Pierce Pt:  34.3712  94.3276   65.553");
        expected.add("");
        expected.add("   Model Layers:");
        expected.add("");
        expected.add("     # Layer             Vel      Top    Thick");
        expected.add("     1 water          1.5000  -4.8143   0.0000");
        expected.add("     2 sediment1      2.5003  -4.8143   0.0337");
        expected.add("     3 sediment2      2.1171  -4.7806   0.0133");
        expected.add("     4 sediment3      0.0526  -4.7674   0.0000");
        expected.add("     5 upper_crust    6.0901  -4.7674  23.9524");
        expected.add("     6 middle_crust   6.3114  19.1850  24.1319");
        expected.add("     8 lower_crust    7.1860  43.3169  22.2356");
        expected.add("     9 mantle         8.0714  65.5525");
        expected.add("");
        expected.add("");
        expected.add("   Applied Layers:");
        expected.add("");
        expected.add("     #     Vel      Top    Thick   i, deg   X, deg    X, km       TT");
        expected.add("     2  2.5003   0.0000  -4.7806  17.7358  0.00000   0.0000   0.0000");
        expected.add("     3  2.1171  -4.7806   0.0133  14.9367 -0.01374  -1.5289  -2.0074");
        expected.add("     5  6.0901  -4.7674  23.9524  47.8543 -0.01371  -1.5254  -2.0009");
        expected.add("     6  6.3114  19.1850  24.1319  50.4692  0.22557  25.0078   3.8740");
        expected.add("     8  7.1860  43.3169  22.2356  61.8255  0.49110  54.2376   9.8981");
        expected.add("     9  8.0714  65.5525           83.5218  0.87066  95.8193  16.4924");
        expected.add("");
        expected.add("");
        expected.add("   Receiver Profile:");
        expected.add("");
        expected.add("                   Lat      Lon    Depth  R Earth        P   P crit");
        expected.add("   Location:   30.0000  90.0000   -1.000  6372.82   776.24   773.53");
        expected.add("   Pierce Pt:  30.7018  90.6584   71.145");
        expected.add("");
        expected.add("   Model Layers:");
        expected.add("");
        expected.add("     # Layer             Vel      Top    Thick");
        expected.add("     1 water          1.5000  -5.1349   0.0000");
        expected.add("     2 sediment1      2.4992  -5.1349   0.0519");
        expected.add("     3 sediment2      0.0000  -5.0830   0.0000");
        expected.add("     4 sediment3      0.0000  -5.0830   0.0000");
        expected.add("     5 upper_crust    5.9981  -5.0830  24.2266");
        expected.add("     6 middle_crust   6.3980  19.1435  26.0017");
        expected.add("     8 lower_crust    7.0977  45.1452  25.9994");
        expected.add("     9 mantle         8.1467  71.1447");
        expected.add("");
        expected.add("");
        expected.add("   Applied Layers:");
        expected.add("");
        expected.add("     #     Vel      Top    Thick   i, deg   X, deg    X, km       TT");
        expected.add("     2  2.4992  -1.0000  -4.0830  17.7202  0.00000   0.0000   0.0000");
        expected.add("     5  5.9981  -5.0830  24.2266  46.8878 -0.01167  -1.2996  -1.7144");
        expected.add("     6  6.3980  19.1435  26.0017  51.4121  0.22045  24.4463   4.1848");
        expected.add("     8  7.0977  45.1452  25.9994  60.5412  0.51381  56.7449  10.6860");
        expected.add("     9  8.1467  71.1447           90.0000  0.92901 102.1777  18.1010");
        expected.add("");
        expected.add("");
        expected.add("   Grid Node Weights:");
        expected.add("");
        expected.add("      grid_id   active_id         weight");
        expected.add("        13338          -1    87.86616698");
        expected.add("        13342          -1    11.43291553");
        expected.add("          846          -1     0.04322838");
        expected.add("        13341          -1     9.08966753");
        expected.add("         3355          -1     0.01046212");
        expected.add("         3356          -1     2.18610381");
        expected.add("        13339         123    65.21547613");
        expected.add("        13340          -1    24.32343507");
        expected.add("         3354          99    80.44584464");
        expected.add("        13344          43    12.94874702");
        expected.add("        13349          45    86.45360622");
        expected.add("        13348         125     8.75204981");
        expected.add("        13347          44    56.95406344");
        expected.add("         3357          12    30.81447214");
        expected.add("        13350          46    50.19707908");
        expected.add("        13070          23     0.41445073");
        expected.add("        21005          85     0.00767119");
        expected.add("");
        expected.add("      Sum of weights = 527.15543980 km");
        expected.add("");
        expected.add("   Head wave Profiles:");
        expected.add("");
        expected.add("     #     Lat      Lon    Moho  R Earth     Vel      Grad       dx   Active");
        expected.add("     0  34.963   94.960  65.679  6371.15  8.0710  0.001372   0.0000      -");
        expected.add("     1  34.889   94.880  65.930  6371.18  8.0701  0.001388   0.0000      -");
        expected.add("     2  34.814   94.800  66.180  6371.21  8.0692  0.001408   0.0000      -");
        expected.add("     3  34.740   94.720  66.433  6371.23  8.0685  0.001430   0.0000      -");
        expected.add("     4  34.666   94.641  66.690  6371.26  8.0681  0.001452   0.0000      -");
        expected.add("     5  34.591   94.561  66.951  6371.28  8.0681  0.001474   0.0000      -");
        expected.add("     6  34.517   94.482  67.215  6371.31  8.0684  0.001497   0.0000      -");
        expected.add("     7  34.442   94.403  67.484  6371.34  8.0690  0.001521   0.0000      -");
        expected.add("     8  34.368   94.324  67.757  6371.36  8.0699  0.001545   0.0539    n");
        expected.add("     9  34.293   94.245  68.034  6371.39  8.0712  0.001569   0.0990    n");
        expected.add("    10  34.219   94.167  68.312  6371.41  8.0727  0.001594   0.0990    n");
        expected.add("    11  34.144   94.088  68.586  6371.44  8.0744  0.001620   0.0990    n");
        expected.add("    12  34.069   94.010  68.859  6371.46  8.0761  0.001646   0.0990    n");
        expected.add("    13  33.994   93.931  69.126  6371.49  8.0782  0.001675   0.0990    n");
        expected.add("    14  33.919   93.853  69.363  6371.52  8.0821  0.001710   0.0990    n");
        expected.add("    15  33.844   93.775  69.588  6371.54  8.0871  0.001746   0.0990    n");
        expected.add("    16  33.770   93.697  69.813  6371.57  8.0921  0.001781   0.0990    n");
        expected.add("    17  33.694   93.619  70.039  6371.59  8.0971  0.001816   0.0990    n");
        expected.add("    18  33.619   93.542  70.265  6371.62  8.1021  0.001850   0.0990    n");
        expected.add("    19  33.544   93.464  70.491  6371.65  8.1069  0.001883   0.0990    n");
        expected.add("    20  33.469   93.387  70.716  6371.67  8.1113  0.001910   0.0990    n");
        expected.add("    21  33.394   93.310  70.939  6371.70  8.1154  0.001931   0.0990    n");
        expected.add("    22  33.319   93.233  71.161  6371.72  8.1189  0.001945   0.0990    n");
        expected.add("    23  33.243   93.156  71.382  6371.75  8.1218  0.001952   0.0990    n");
        expected.add("    24  33.168   93.079  71.601  6371.77  8.1242  0.001952   0.0990    n");
        expected.add("    25  33.093   93.002  71.810  6371.80  8.1263  0.001944   0.0990    n");
        expected.add("    26  33.017   92.926  72.007  6371.83  8.1284  0.001931   0.0990    n");
        expected.add("    27  32.942   92.849  72.196  6371.85  8.1306  0.001918   0.0990    n");
        expected.add("    28  32.866   92.773  72.378  6371.88  8.1331  0.001906   0.0990    n");
        expected.add("    29  32.790   92.697  72.546  6371.90  8.1354  0.001891   0.0990    n");
        expected.add("    30  32.715   92.621  72.691  6371.93  8.1372  0.001873   0.0990     y");
        expected.add("    31  32.639   92.545  72.816  6371.95  8.1382  0.001848   0.0990     y");
        expected.add("    32  32.563   92.469  72.935  6371.98  8.1376  0.001817   0.0990     y");
        expected.add("    33  32.487   92.393  73.048  6372.00  8.1353  0.001779   0.0990     y");
        expected.add("    34  32.412   92.318  73.156  6372.03  8.1321  0.001736   0.0990     y");
        expected.add("    35  32.336   92.242  73.262  6372.06  8.1283  0.001691   0.0990     y");
        expected.add("    36  32.260   92.167  73.368  6372.08  8.1246  0.001646   0.0990     y");
        expected.add("    37  32.184   92.092  73.473  6372.11  8.1206  0.001600   0.0990     y");
        expected.add("    38  32.108   92.017  73.573  6372.13  8.1157  0.001553   0.0990     y");
        expected.add("    39  32.032   91.942  73.665  6372.16  8.1090  0.001503   0.0990     y");
        expected.add("    40  31.956   91.867  73.745  6372.18  8.1002  0.001450   0.0990     y");
        expected.add("    41  31.879   91.792  73.786  6372.21  8.0900  0.001393   0.0990     y");
        expected.add("    42  31.803   91.718  73.801  6372.23  8.0788  0.001333   0.0990     y");
        expected.add("    43  31.727   91.643  73.804  6372.26  8.0675  0.001272   0.0990     y");
        expected.add("    44  31.651   91.569  73.799  6372.28  8.0563  0.001211   0.0990     y");
        expected.add("    45  31.574   91.495  73.784  6372.31  8.0459  0.001153   0.0990     y");
        expected.add("    46  31.498   91.421  73.752  6372.34  8.0373  0.001099   0.0990     y");
        expected.add("    47  31.422   91.347  73.713  6372.36  8.0304  0.001050   0.0990     y");
        expected.add("    48  31.345   91.273  73.668  6372.39  8.0251  0.001007   0.0990     y");
        expected.add("    49  31.269   91.199  73.620  6372.41  8.0215  0.000969   0.0990     y");
        expected.add("    50  31.192   91.126  73.567  6372.44  8.0193  0.000936   0.0990     y");
        expected.add("    51  31.115   91.052  73.509  6372.46  8.0189  0.000908   0.0990     y");
        expected.add("    52  31.039   90.979  73.447  6372.49  8.0202  0.000884   0.0990     y");
        expected.add("    53  30.962   90.906  73.384  6372.51  8.0218  0.000862   0.0990     y");
        expected.add("    54  30.885   90.833  73.321  6372.54  8.0231  0.000840   0.0990     y");
        expected.add("    55  30.809   90.760  73.258  6372.56  8.0240  0.000817   0.0990     y");
        expected.add("    56  30.732   90.687  73.196  6372.59  8.0244  0.000793   0.0881     y");
        expected.add("    57  30.655   90.614  73.030  6372.61  8.0343  0.000808   0.0000      -");
        expected.add("    58  30.578   90.541  72.819  6372.64  8.0481  0.000839   0.0000      -");
        expected.add("    59  30.501   90.469  72.606  6372.66  8.0616  0.000868   0.0000      -");
        expected.add("    60  30.424   90.396  72.390  6372.69  8.0751  0.000898   0.0000      -");
        expected.add("    61  30.347   90.324  72.171  6372.71  8.0884  0.000926   0.0000      -");
        expected.add("    62  30.270   90.252  71.950  6372.74  8.1016  0.000953   0.0000      -");
        expected.add("    63  30.193   90.180  71.728  6372.76  8.1146  0.000980   0.0000      -");
        expected.add("    64  30.116   90.108  71.502  6372.79  8.1276  0.001007   0.0000      -");
        expected.add("    65  30.039   90.036  71.266  6372.81  8.1403  0.001036   0.0000      -");
        expected.add("");
        expected.add("");
        expected.add("   Head wave Profile Interpolation Coefficients:");
        expected.add("");
        expected.add("     #     id     coeff     id     coeff     id     coeff     id     coeff");
        expected.add("     0  13341  0.273074  13342  0.135656    846  0.576477  13301  0.014792");
        expected.add("     1  13341  0.331264  13342  0.194470    846  0.469527  13301  0.004740");
        expected.add("     2  13338  0.005054  13342  0.253604    846  0.362245  13301  0.000077  13341  0.379021");
        expected.add("     3  13338  0.025337  13342  0.302084    846  0.265608  13341  0.406971");
        expected.add("     4  13338  0.060933  13342  0.335327    846  0.184211  13341  0.419530");
        expected.add("     5  13338  0.111547  13342  0.353550    846  0.117835  13341  0.417068");
        expected.add("     6  13338  0.176972  13342  0.356962    846  0.066272  13341  0.399795");
        expected.add("     7  13338  0.257106  13342  0.345663    846  0.029421  13341  0.367810");
        expected.add("     8  13338  0.351957  13342  0.319645    846  0.007290  13341  0.321107");
        expected.add("     9  13342  0.278825  13341  0.259531   3355  0.000035  13338  0.461609");
        expected.add("    10  13342  0.229306  13341  0.192071   3355  0.000464  13338  0.576358   3356  0.001801");
        expected.add("    11  13342  0.176214  13341  0.128181   3355  0.000461  13338  0.688402   3356  0.006742");
        expected.add("    12  13342  0.120383  13341  0.067029  13338  0.798623   3356  0.013965");
        expected.add("    13  13338  0.897828  13339  0.002908   3356  0.025927  13342  0.060274  13341  0.013063");
        expected.add("    14  13340  0.006925  13339  0.050273   3356  0.034315  13342  0.010685  13338  0.897804");
        expected.add("    15  13340  0.045375  13339  0.118220   3356  0.035162  13342  0.000182  13338  0.801060");
        expected.add("    16  13340  0.089052  13339  0.191253   3356  0.030918  13338  0.688777");
        expected.add("    17  13340  0.131054  13339  0.266141   3356  0.024818  13338  0.577987");
        expected.add("    18  13340  0.171228  13339  0.342855   3356  0.016891  13338  0.469026");
        expected.add("    19  13338  0.363792  13340  0.207675   3354  0.003204  13339  0.416888   3356  0.008441");
        expected.add("    20  13338  0.269734  13340  0.232945   3354  0.019406  13339  0.476103   3356  0.001811");
        expected.add("    21  13338  0.185400  13340  0.248489   3354  0.050154  13339  0.515956");
        expected.add("    22  13338  0.114824  13340  0.250275   3354  0.096473  13339  0.538428");
        expected.add("    23  13338  0.060441  13340  0.235866   3354  0.158990  13339  0.544703");
        expected.add("    24  13338  0.023149  13340  0.204847   3354  0.238119  13344  0.000481  13339  0.533405");
        expected.add("    25  13338  0.003718  13340  0.165234   3354  0.325839  13344  0.010236  13339  0.494973");
        expected.add("    26  13339  0.431495  13340  0.119237   3354  0.419942  13344  0.029326");
        expected.add("    27  13339  0.357792  13340  0.076027   3354  0.511254  13344  0.054927");
        expected.add("    28  13339  0.278238  13340  0.038840   3354  0.596367  13349  0.000174  13344  0.086381");
        expected.add("    29  13339  0.200408  13340  0.011465   3354  0.660119  13349  0.011919  13344  0.116089");
        expected.add("    30  13344  0.140761  13339  0.127576   3354  0.687023  13349  0.044640");
        expected.add("    31  13344  0.152783  13339  0.067346   3354  0.678367  13349  0.101504");
        expected.add("    32  13344  0.148487  13339  0.028712   3354  0.642767  13348  0.005325  13349  0.174708");
        expected.add("    33  13344  0.137058  13339  0.007654   3354  0.579096  13348  0.021125  13349  0.255067");
        expected.add("    34  13344  0.116433  13339  0.000060   3354  0.497652  13348  0.041220  13349  0.344636");
        expected.add("    35  13348  0.062488  13349  0.440591  13344  0.089428   3354  0.407494");
        expected.add("    36  13348  0.083076  13349  0.537285  13344  0.061683   3354  0.317955");
        expected.add("    37  13347  0.003802  13349  0.629681  13344  0.034435   3354  0.231724  13348  0.100357");
        expected.add("    38  13347  0.020392  13349  0.705120  13344  0.011358   3354  0.154110  13348  0.109020");
        expected.add("    39  13347  0.055344  13349  0.750479   3354  0.083145  13348  0.111032");
        expected.add("    40  13348  0.098428  13347  0.116261   3357  0.001968  13349  0.754581   3354  0.028763");
        expected.add("    41  13348  0.077317  13347  0.185683   3357  0.025085  13349  0.707877   3354  0.004037");
        expected.add("    42  13349  0.624656  13348  0.051349  13347  0.259962   3357  0.064033");
        expected.add("    43  13349  0.529512  13348  0.029230  13347  0.330390   3357  0.110868");
        expected.add("    44  13349  0.429118  13348  0.012361  13347  0.395569   3357  0.162952");
        expected.add("    45  13349  0.329661  13348  0.001968  13347  0.446858  13350  0.007418   3357  0.214096");
        expected.add("    46  13349  0.237960  13347  0.473535  13350  0.031030   3357  0.257474");
        expected.add("    47  13349  0.160552  13347  0.481981  13350  0.070917   3357  0.286550");
        expected.add("    48  13349  0.098821  13347  0.474747  13350  0.126492   3357  0.299940");
        expected.add("    49  13349  0.052292  13347  0.452307  13350  0.197283   3357  0.298118");
        expected.add("    50  13349  0.020598  13347  0.415030  13350  0.282919   3357  0.281453");
        expected.add("    51  13349  0.003482  13347  0.361289  13070  0.001882  13350  0.381264   3357  0.252082");
        expected.add("    52  13070  0.005630  13350  0.491386   3357  0.210936  13347  0.292048");
        expected.add("    53  13070  0.008945  13350  0.605429   3357  0.165870  13347  0.219756");
        expected.add("    54  13070  0.010244  13350  0.721424  21005  0.000053   3357  0.118748  13347  0.149532");
        expected.add("    55  13070  0.008562  13350  0.839907  21005  0.000505   3357  0.068339  13347  0.082687");
        expected.add("    56  13070  0.003169  13350  0.963084  21005  0.000165   3357  0.014822  13347  0.018759");
        expected.add("    57  13350  0.911521  13070  0.000936     57  0.039389  20825  0.032851  21005  0.015303");
        expected.add("    58  13350  0.793803  13070  0.000553     57  0.088893  20825  0.084210  21005  0.032541");
        expected.add("    59  13350  0.682465  13070  0.000005     57  0.132345  20825  0.141657  21005  0.043527");
        expected.add("    60  21005  0.048602  13350  0.576629     57  0.169213  20825  0.205556");
        expected.add("    61  21005  0.047911  13350  0.476556     57  0.200306  20825  0.275226");
        expected.add("    62  21005  0.041940  13350  0.381765     57  0.226117  20825  0.350178");
        expected.add("    63  21005  0.031545  13350  0.291398     57  0.247505  20825  0.429552");
        expected.add("    64  20824  0.003006  20825  0.508472  21005  0.018623  13350  0.206700     57  0.263200");
        expected.add("    65  20824  0.019877  20825  0.572600  21005  0.006732  13350  0.135448     57  0.265343");
        expected.add("");
        expected.add("");
        expected.add("Horizontal slowness = 763.791441092 sec/radian");

        for (int i=0; i<actual.size(); ++i) System.out.println(actual.get(i));

        //assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));
    }

    @Test
    public void testGetTravelTime() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetTravelTime()");
        assertEquals(101.2545, slbm.getTravelTime(), 1e-2);
    }

    @Test
    public void testGetPhase() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetPhase()");
        assertEquals("Pn", slbm.getPhase());
    }

    @Test
    public void testGetDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetDistance()");
        assertEquals(6.53306, slbm.getDistance() * rtd, 1e-4);
    }

    @Test
    public void testGetSourceDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSourceDistance()");
        assertEquals(0.837102, slbm.getSourceDistance() * rtd, 1e-3);
    }

    @Test
    public void testGetReceiverDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetReceiverDistance()");
        assertEquals(0.901937, slbm.getReceiverDistance() * rtd, 1e-3);
    }

    @Test
    public void testGetHeadwaveDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetHeadwaveDistance()");
        assertEquals(4.79405, slbm.getHeadwaveDistance() * rtd, 1e-3);
    }

    @Test
    public void testGetHeadwaveDistanceKm() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetHeadwaveDistanceKm()");
        assertEquals(527.1236985, slbm.getHeadwaveDistanceKm(), 1e-1);
    }

    @Test
    public void testGetTravelTimeComponents() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetTravelTimeComponents()");
        double[] actual = getDoubles(slbm.getTravelTimeComponents(), false);
        double[] expected = new double[] { 101.254100, 17.331220, 18.827075,
                65.186551, -0.090746 };

        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-1);
    }

    @Test
    public void testGetWeights() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetWeights()");
        GridWeight weights = slbm.getWeights();

        // for (int i=0; i<weights.node.length; ++i)
        // {
        // GridProfile node = slbm.getGridData(weights.node[i]);
        // System.out.printf("%10.4f %10.4f%n", node.lat*rtd, node.lon*rtd);
        // }

        ArrayList<String> actual = getRecords(weights.toString(), false);

        ArrayList<String> expected = new ArrayList<String>(20);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add(" 13338    87.8662");
        expected.add(" 13342    11.4329");
        expected.add("   846     0.0432");
        expected.add(" 13341     9.0897");
        expected.add("  3355     0.0105");
        expected.add("  3356     2.1861");
        expected.add(" 13339    65.2155");
        expected.add(" 13340    24.3234");
        expected.add("  3354    80.4458");
        expected.add(" 13344    12.9487");
        expected.add(" 13349    86.4536");
        expected.add(" 13348     8.7520");
        expected.add(" 13347    56.9541");
        expected.add("  3357    30.8145");
        expected.add(" 13350    50.1971");
        expected.add(" 13070     0.4145");
        expected.add(" 21005     0.0077");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

        // the sum of the weights should be equal to the headwave distance
        // in km.
        assertEquals(weights.getSum(), slbm.getHeadwaveDistanceKm(), 1e-2);
    }

    @Test
    public void testGetWeightsSource() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetWeightsSource()");
        GridWeight weights = slbm.getWeightsSource();
        ArrayList<String> actual = getRecords(weights.toString(), false);

        ArrayList<String> expected = new ArrayList<String>(7);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add(" 13341     0.2425");
        expected.add(" 13342     0.1078");
        expected.add("   846     0.6284");
        expected.add(" 13301     0.0213");

        assertEquals(expected.size(), actual.size());
        for (int i = 0; i < expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

        // the sum of the weights should be equal to one (three corners of
        // triangle).
        assertEquals(1., weights.getSum(), 1e-2);
    }

    @Test
    public void testGetActiveNodeWeightsSource() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeWeightsSource()");
        ArrayList<String> actual = getRecords(
                slbm.getActiveNodeWeightsSource().toString(), false);
        ArrayList<String> expected = new ArrayList<String>(7);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add("    -1     0.2425");
        expected.add("    -1     0.1078");
        expected.add("    -1     0.6284");
        expected.add("    -1     0.0213");


        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));
    }

    @Test
    public void testGetWeightsReceiver() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetWeightsReceiver()");
        GridWeight weights = slbm.getWeightsReceiver();
        ArrayList<String> actual = getRecords(weights.toString(), false);

        ArrayList<String> expected = new ArrayList<String>(8);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add(" 20824     0.0340");
        expected.add(" 20825     0.5975");
        expected.add(" 21005     0.0024");
        expected.add(" 13350     0.1042");
        expected.add("    57     0.2620");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

        // the sum of the weights should be equal to one (three corners of
        // triangle).
        assertEquals(1., weights.getSum(), 1e-2);
    }

    @Test
    public void testGetActiveNodeWeightsReceiver() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeWeightsReceiver()");
        GridWeight weights = slbm.getActiveNodeWeightsReceiver();
        ArrayList<String> actual = getRecords(weights.toString(), false);

        ArrayList<String> expected = new ArrayList<String>(8);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add("    51     0.0340");
        expected.add("    52     0.5975");
        expected.add("    85     0.0024");
        expected.add("    46     0.1042");
        expected.add("     0     0.2620");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

        // the sum of the weights should be equal to one (three corners of
        // triangle).
        assertEquals(1., weights.getSum(), 1e-2);
    }

    @Test
    public void testGetSourceNodeIds() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSourceNodeIds()");
        int[] actual = getInts(slbm.getSourceNodeIds(), false);
        int[] expected = new int[] {13341, 13342, 846, 13301};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i]);

    }

    @Test
    public void testGetSourceCoefficients() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSourceCoefficients()");
        double[] actual = getDoubles(slbm.getSourceCoefficients(), false);
        double[] expected = new double[] {0.242457, 0.107772, 0.628427, 0.021344};

        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-3);

        assertEquals(1.000000, getSum(actual), 1e-4);

    }

    @Test
    public void testGetReceiverNodeIds() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetReceiverNodeIds()");
        int[] actual = getInts(slbm.getReceiverNodeIds(), false);
        int[] expected = new int[] {20824, 20825, 21005, 13350, 57};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i]);

    }

    @Test
    public void testGetReceiverCoefficients() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetReceiverCoefficients()");
        double[] actual = getDoubles(slbm.getReceiverCoefficients(), false);
        double[] expected = new double[] {0.033991, 0.597455, 0.002360, 0.104177, 0.262017};

        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-3);

        assertEquals(1.000000, getSum(actual), 1e-4);

    }

    @Test
    public void testGetGridData() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGridData()");
        ArrayList<String> actual = getRecords(slbm.getGridData(57).toString(), false);
        ArrayList<String> expected = new ArrayList<String>(18);
        expected.add("GridProfile:");
        expected.add("");
        expected.add("  Node ID  :         57");
        expected.add("  Latitude :    30.5474");
        expected.add("  Longitude:    89.5330");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.522179     0.0000     1.5000     0.0000");
        expected.add("   -5.522179     0.1001     2.5013     1.1987");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081    24.9502     6.0032     3.4582");
        expected.add("   19.528114     0.0000     6.4034     3.6960");
        expected.add("   19.528114    26.7808     6.1350     3.5024");
        expected.add("   46.308876    26.7813     7.1038     3.8958");
        expected.add("   73.090126                8.1063     4.5955");
        expected.add("               P Grad     S Grad");
        expected.add("             0.000720  -0.000055");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testSetGridData() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testSetGridData()");

        GridProfile n0 = slbm.getGridData(57);

        GridProfile n = slbm.getGridData(57);

        for (int i=0; i<n.depth.length; ++i)
        {
            n.depth[i] += 1;
            n.velocity[SlbmInterface.PWAVE][i] += 0.1;
            n.velocity[SlbmInterface.SWAVE][i] -= 0.1;
        }

        slbm.setGridData(n);

        ArrayList<String> actual = getRecords(slbm.getGridData(57).toString(), false);
        ArrayList<String> expected = new ArrayList<String>(18);
        expected.add("GridProfile:");
        expected.add("");
        expected.add("  Node ID  :         57");
        expected.add("  Latitude :    30.5474");
        expected.add("  Longitude:    89.5330");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -4.522179     0.0000     1.6000    -0.1000");
        expected.add("   -4.522179     0.1001     2.6013     1.0987");
        expected.add("   -4.422081     0.0000     0.1000    -0.1000");
        expected.add("   -4.422081     0.0000     0.1000    -0.1000");
        expected.add("   -4.422081    24.9502     6.1032     3.3582");
        expected.add("   20.528114     0.0000     6.5034     3.5960");
        expected.add("   20.528114    26.7808     6.2350     3.4024");
        expected.add("   47.308876    26.7813     7.2038     3.7958");
        expected.add("   74.090126                8.2063     4.4955");
        expected.add("               P Grad     S Grad");
        expected.add("             0.000720  -0.000055");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
           assertEquals(expected.get(i), actual.get(i));

        slbm.setGridData(n0);
        actual = getRecords(slbm.getGridData(57).toString(), false);
        expected = new ArrayList<String>(18);
        expected.add("GridProfile:");
        expected.add("");
        expected.add("  Node ID  :         57");
        expected.add("  Latitude :    30.5474");
        expected.add("  Longitude:    89.5330");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.522179     0.0000     1.5000     0.0000");
        expected.add("   -5.522179     0.1001     2.5013     1.1987");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081    24.9502     6.0032     3.4582");
        expected.add("   19.528114     0.0000     6.4034     3.6960");
        expected.add("   19.528114    26.7808     6.1350     3.5024");
        expected.add("   46.308876    26.7813     7.1038     3.8958");
        expected.add("   73.090126                8.1063     4.5955");
        expected.add("               P Grad     S Grad");
        expected.add("             0.000720  -0.000055");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
           assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testSetActiveNodeData()
    {
        if (verbosity > 0)
            System.out.println("testSetActiveNodeData()");
        // TODO
    }

    @Test
    public void testGetInterpolatedPoint() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetInterpolatedPoint()");
        ArrayList<String> actual = getRecords(
                slbm.getInterpolatedPoint(30 * dtr, 90 * dtr).toString(), false);

        ArrayList<String> expected = new ArrayList<String>(23);
        expected.add("QueryProfile: ");
        expected.add("   Latitude :    30.0000");
        expected.add("   Longitude:    90.0000");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.134463     0.0000     1.5000     0.0000");
        expected.add("   -5.134463     0.0519     2.4992     1.1985");
        expected.add("   -5.082559     0.0000     0.0000     0.0000");
        expected.add("   -5.082559     0.0000     0.0000     0.0000");
        expected.add("   -5.082559    24.2266     5.9981     3.4857");
        expected.add("   19.144014     0.0000     6.3980     3.6954");
        expected.add("   19.144014    26.0017     6.1047     3.6097");
        expected.add("   45.145706    25.9994     7.0977     3.8952");
        expected.add("   71.145145                8.1467     4.8026");
        expected.add("               P Grad     S Grad");
        expected.add("               0.001051  -0.000051");
        expected.add("");
        expected.add("    NodeId      Coeff");
        expected.add("     20824     0.0340");
        expected.add("     20825     0.5975");
        expected.add("     21005     0.0024");
        expected.add("     13350     0.1042");
        expected.add("        57     0.2620");

        assertEquals(expected.size(), actual.size());
        for (int i = 0; i < expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));
    }

    @Test
    public void testGetInterpolatedTransect() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetInterpolatedTransect()");
        ArrayList<Double> lats = new ArrayList<Double>();
        ArrayList<Double> lons = new ArrayList<Double>();

        lats.add(30. * dtr);
        lons.add(90. * dtr);
        lats.add(31. * dtr);
        lons.add(91. * dtr);
        lats.add(32. * dtr);
        lons.add(92. * dtr);
        lats.add(33. * dtr);
        lons.add(93. * dtr);
        ArrayList<String> actual = getRecords(
                slbm.getInterpolatedTransect(lats, lons).toString(), false);

        ArrayList<String> expected = new ArrayList<String>(95);
        expected.add("[QueryProfile: ");
        expected.add("   Latitude :    30.0000");
        expected.add("   Longitude:    90.0000");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.134463     0.0000     1.5000     0.0000");
        expected.add("   -5.134463     0.0519     2.4992     1.1985");
        expected.add("   -5.082559     0.0000     0.0000     0.0000");
        expected.add("   -5.082559     0.0000     0.0000     0.0000");
        expected.add("   -5.082559    24.2266     5.9981     3.4857");
        expected.add("   19.144014     0.0000     6.3980     3.6954");
        expected.add("   19.144014    26.0017     6.1047     3.6097");
        expected.add("   45.145706    25.9994     7.0977     3.8952");
        expected.add("   71.145145                8.1467     4.8026");
        expected.add("               P Grad     S Grad");
        expected.add("               0.001051  -0.000051");
        expected.add("");
        expected.add("    NodeId      Coeff");
        expected.add("     20824     0.0340");
        expected.add("     20825     0.5975");
        expected.add("     21005     0.0024");
        expected.add("     13350     0.1042");
        expected.add("        57     0.2620");
        expected.add("");
        expected.add(", QueryProfile: ");
        expected.add("   Latitude :    31.0000");
        expected.add("   Longitude:    91.0000");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -4.888634     0.0000     1.5000     0.0000");
        expected.add("   -4.888634     0.0933     2.4999     1.1955");
        expected.add("   -4.795326     0.0000     0.0000     0.0000");
        expected.add("   -4.795326     0.0000     0.0000     0.0000");
        expected.add("   -4.795326    24.8510     5.9998     3.4866");
        expected.add("   20.055683     0.0000     6.3997     3.6860");
        expected.add("   20.055683    26.6672     6.1549     3.5174");
        expected.add("   46.722865    26.6676     7.0997     3.8852");
        expected.add("   73.390446                8.0239     4.5141");
        expected.add("               P Grad     S Grad");
        expected.add("               0.000895   0.000024");
        expected.add("");
        expected.add("    NodeId      Coeff");
        expected.add("     13070     0.0017");
        expected.add("     13350     0.5100");
        expected.add("      3357     0.2352");
        expected.add("     13347     0.2531");
        expected.add("");
        expected.add(", QueryProfile: ");
        expected.add("   Latitude :    32.0000");
        expected.add("   Longitude:    92.0000");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -4.888677     0.0000     1.5000     0.0000");
        expected.add("   -4.888677     0.0519     2.5001     1.2052");
        expected.add("   -4.836799     0.0000     0.0000     0.0000");
        expected.add("   -4.836799     0.0000     0.0000     0.0000");
        expected.add("   -4.836799    24.9471     6.0001     3.4491");
        expected.add("   20.110323     0.0000     6.4002     3.7159");
        expected.add("   20.110323    26.7679     6.1684     3.4781");
        expected.add("   46.878233    26.7728     7.1002     3.9167");
        expected.add("   73.651018                8.1166     4.6600");
        expected.add("               P Grad     S Grad");
        expected.add("               0.001538   0.000298");
        expected.add("");
        expected.add("    NodeId      Coeff");
        expected.add("     13347     0.0324");
        expected.add("     13349     0.8116");
        expected.add("     13344     0.0021");
        expected.add("      3354     0.0777");
        expected.add("     13348     0.0761");
        expected.add("");
        expected.add(", QueryProfile: ");
        expected.add("   Latitude :    33.0000");
        expected.add("   Longitude:    93.0000");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.054384     0.0000     1.5000     0.0000");
        expected.add("   -5.054384     0.0867     2.5006     1.2032");
        expected.add("   -4.967729     0.0000     0.0000     0.0000");
        expected.add("   -4.967729     0.0000     0.0000     0.0000");
        expected.add("   -4.967729    24.4512     6.0014     3.4272");
        expected.add("   19.483430     0.0000     6.4015     3.7100");
        expected.add("   19.483430    26.2379     6.1638     3.4457");
        expected.add("   45.721312    26.2399     7.1017     3.9105");
        expected.add("   71.961170                8.1285     4.5840");
        expected.add("               P Grad     S Grad");
        expected.add("               0.001951   0.000437");
        expected.add("");
        expected.add("    NodeId      Coeff");
        expected.add("     13339     0.4930");
        expected.add("     13340     0.1013");
        expected.add("      3354     0.3677");
        expected.add("     13344     0.0380");
        expected.add("");
        expected.add("]");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testGetGreatCircleData() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGreatCircleData()");
        ArrayList<String> actual = getRecords(
                slbm.getGreatCircleData().toString(), false);

        ArrayList<String> expected = new ArrayList<String>(78);
        expected.add("Source/Receiver Profiles:");
        expected.add(" -4.8143   1.5000     -5.1349   1.5000");
        expected.add(" -4.8143   2.5003     -5.1349   2.4992");
        expected.add(" -4.7806   2.1171     -5.0830   0.0000");
        expected.add(" -4.7674   0.0526     -5.0830   0.0000");
        expected.add(" -4.7674   6.0901     -5.0830   5.9981");
        expected.add(" 19.1850   6.3114     19.1435   6.3980");
        expected.add(" 19.1850   6.2210     19.1435   6.1047");
        expected.add(" 43.3169   7.1860     45.1452   7.0977");
        expected.add(" 65.5525   8.0714     71.1447   8.1467");
        expected.add("");
        expected.add("Headwave velocities, gradients,  nodeIds and coefficients");
        expected.add("  8.0710  0.001372     13341  0.273074     13342  0.135656       846  0.576477     13301  0.014792");
        expected.add("  8.0701  0.001388     13341  0.331264     13342  0.194470       846  0.469527     13301  0.004740");
        expected.add("  8.0692  0.001408     13338  0.005054     13342  0.253604       846  0.362245     13301  0.000077     13341  0.379021");
        expected.add("  8.0685  0.001430     13338  0.025337     13342  0.302084       846  0.265608     13341  0.406971");
        expected.add("  8.0681  0.001452     13338  0.060933     13342  0.335327       846  0.184211     13341  0.419530");
        expected.add("  8.0681  0.001474     13338  0.111547     13342  0.353550       846  0.117835     13341  0.417068");
        expected.add("  8.0684  0.001497     13338  0.176972     13342  0.356962       846  0.066272     13341  0.399795");
        expected.add("  8.0690  0.001521     13338  0.257106     13342  0.345663       846  0.029421     13341  0.367810");
        expected.add("  8.0699  0.001545     13338  0.351957     13342  0.319645       846  0.007290     13341  0.321107");
        expected.add("  8.0712  0.001569     13342  0.278825     13341  0.259531      3355  0.000035     13338  0.461609");
        expected.add("  8.0727  0.001594     13342  0.229306     13341  0.192071      3355  0.000464     13338  0.576358      3356  0.001801");
        expected.add("  8.0744  0.001620     13342  0.176214     13341  0.128181      3355  0.000461     13338  0.688402      3356  0.006742");
        expected.add("  8.0761  0.001646     13342  0.120383     13341  0.067029     13338  0.798623      3356  0.013965");
        expected.add("  8.0782  0.001675     13338  0.897828     13339  0.002908      3356  0.025927     13342  0.060274     13341  0.013063");
        expected.add("  8.0821  0.001710     13340  0.006925     13339  0.050273      3356  0.034315     13342  0.010685     13338  0.897804");
        expected.add("  8.0871  0.001746     13340  0.045375     13339  0.118220      3356  0.035162     13342  0.000182     13338  0.801060");
        expected.add("  8.0921  0.001781     13340  0.089052     13339  0.191253      3356  0.030918     13338  0.688777");
        expected.add("  8.0971  0.001816     13340  0.131054     13339  0.266141      3356  0.024818     13338  0.577987");
        expected.add("  8.1021  0.001850     13340  0.171228     13339  0.342855      3356  0.016891     13338  0.469026");
        expected.add("  8.1069  0.001883     13338  0.363792     13340  0.207675      3354  0.003204     13339  0.416888      3356  0.008441");
        expected.add("  8.1113  0.001910     13338  0.269734     13340  0.232945      3354  0.019406     13339  0.476103      3356  0.001811");
        expected.add("  8.1154  0.001931     13338  0.185400     13340  0.248489      3354  0.050154     13339  0.515956");
        expected.add("  8.1189  0.001945     13338  0.114824     13340  0.250275      3354  0.096473     13339  0.538428");
        expected.add("  8.1218  0.001952     13338  0.060441     13340  0.235866      3354  0.158990     13339  0.544703");
        expected.add("  8.1242  0.001952     13338  0.023149     13340  0.204847      3354  0.238119     13344  0.000481     13339  0.533405");
        expected.add("  8.1263  0.001944     13338  0.003718     13340  0.165234      3354  0.325839     13344  0.010236     13339  0.494973");
        expected.add("  8.1284  0.001931     13339  0.431495     13340  0.119237      3354  0.419942     13344  0.029326");
        expected.add("  8.1306  0.001918     13339  0.357792     13340  0.076027      3354  0.511254     13344  0.054927");
        expected.add("  8.1331  0.001906     13339  0.278238     13340  0.038840      3354  0.596367     13349  0.000174     13344  0.086381");
        expected.add("  8.1354  0.001891     13339  0.200408     13340  0.011465      3354  0.660119     13349  0.011919     13344  0.116089");
        expected.add("  8.1372  0.001873     13344  0.140761     13339  0.127576      3354  0.687023     13349  0.044640");
        expected.add("  8.1382  0.001848     13344  0.152783     13339  0.067346      3354  0.678367     13349  0.101504");
        expected.add("  8.1376  0.001817     13344  0.148487     13339  0.028712      3354  0.642767     13348  0.005325     13349  0.174708");
        expected.add("  8.1353  0.001779     13344  0.137058     13339  0.007654      3354  0.579096     13348  0.021125     13349  0.255067");
        expected.add("  8.1321  0.001736     13344  0.116433     13339  0.000060      3354  0.497652     13348  0.041220     13349  0.344636");
        expected.add("  8.1283  0.001691     13348  0.062488     13349  0.440591     13344  0.089428      3354  0.407494");
        expected.add("  8.1246  0.001646     13348  0.083076     13349  0.537285     13344  0.061683      3354  0.317955");
        expected.add("  8.1206  0.001600     13347  0.003802     13349  0.629681     13344  0.034435      3354  0.231724     13348  0.100357");
        expected.add("  8.1157  0.001553     13347  0.020392     13349  0.705120     13344  0.011358      3354  0.154110     13348  0.109020");
        expected.add("  8.1090  0.001503     13347  0.055344     13349  0.750479      3354  0.083145     13348  0.111032");
        expected.add("  8.1002  0.001450     13348  0.098428     13347  0.116261      3357  0.001968     13349  0.754581      3354  0.028763");
        expected.add("  8.0900  0.001393     13348  0.077317     13347  0.185683      3357  0.025085     13349  0.707877      3354  0.004037");
        expected.add("  8.0788  0.001333     13349  0.624656     13348  0.051349     13347  0.259962      3357  0.064033");
        expected.add("  8.0675  0.001272     13349  0.529512     13348  0.029230     13347  0.330390      3357  0.110868");
        expected.add("  8.0563  0.001211     13349  0.429118     13348  0.012361     13347  0.395569      3357  0.162952");
        expected.add("  8.0459  0.001153     13349  0.329661     13348  0.001968     13347  0.446858     13350  0.007418      3357  0.214096");
        expected.add("  8.0373  0.001099     13349  0.237960     13347  0.473535     13350  0.031030      3357  0.257474");
        expected.add("  8.0304  0.001050     13349  0.160552     13347  0.481981     13350  0.070917      3357  0.286550");
        expected.add("  8.0251  0.001007     13349  0.098821     13347  0.474747     13350  0.126492      3357  0.299940");
        expected.add("  8.0215  0.000969     13349  0.052292     13347  0.452307     13350  0.197283      3357  0.298118");
        expected.add("  8.0193  0.000936     13349  0.020598     13347  0.415030     13350  0.282919      3357  0.281453");
        expected.add("  8.0189  0.000908     13349  0.003482     13347  0.361289     13070  0.001882     13350  0.381264      3357  0.252082");
        expected.add("  8.0202  0.000884     13070  0.005630     13350  0.491386      3357  0.210936     13347  0.292048");
        expected.add("  8.0218  0.000862     13070  0.008945     13350  0.605429      3357  0.165870     13347  0.219756");
        expected.add("  8.0231  0.000840     13070  0.010244     13350  0.721424     21005  0.000053      3357  0.118748     13347  0.149532");
        expected.add("  8.0240  0.000817     13070  0.008562     13350  0.839907     21005  0.000505      3357  0.068339     13347  0.082687");
        expected.add("  8.0244  0.000793     13070  0.003169     13350  0.963084     21005  0.000165      3357  0.014822     13347  0.018759");
        expected.add("  8.0343  0.000808     13350  0.911521     13070  0.000936        57  0.039389     20825  0.032851     21005  0.015303");
        expected.add("  8.0481  0.000839     13350  0.793803     13070  0.000553        57  0.088893     20825  0.084210     21005  0.032541");
        expected.add("  8.0616  0.000868     13350  0.682465     13070  0.000005        57  0.132345     20825  0.141657     21005  0.043527");
        expected.add("  8.0751  0.000898     21005  0.048602     13350  0.576629        57  0.169213     20825  0.205556");
        expected.add("  8.0884  0.000926     21005  0.047911     13350  0.476556        57  0.200306     20825  0.275226");
        expected.add("  8.1016  0.000953     21005  0.041940     13350  0.381765        57  0.226117     20825  0.350178");
        expected.add("  8.1146  0.000980     21005  0.031545     13350  0.291398        57  0.247505     20825  0.429552");
        expected.add("  8.1276  0.001007     20824  0.003006     20825  0.508472     21005  0.018623     13350  0.206700        57  0.263200");
        expected.add("  8.1403  0.001036     20824  0.019877     20825  0.572600     21005  0.006732     13350  0.135448        57  0.265343");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testGetGreatCircleLocations() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGreatCircleLocations()");
        double[][] actual = slbm.getGreatCircleLocations();
        boolean choice = false;
        if (choice)
        {
            int n = actual[0].length;
            double[] lat = actual[0];
            double[] lon = actual[1];
            double[] depth = actual[2];
            System.out.printf("double[] lat = new double[%d];%n", n);
            System.out.printf("double[] lon = new double[%d];%n", n);
            System.out.printf("double[] depth = new double[%d];%n", n);
            for (int i = 0; i < n; ++i)
                System.out
                .printf("lat[%3d] = %9.4f; lon[%3d] = %9.4f; depth[%3d] = %9.4f;%n",
                        i, lat[i] * rtd, i, lon[i] * rtd, i, depth[i]);
        }
        else
        {
            double[] lat = new double[66];
            double[] lon = new double[66];
            double[] depth = new double[66];
            lat[  0] =   34.9629; lon[  0] =   94.9600; depth[  0] =   65.6788;
            lat[  1] =   34.8887; lon[  1] =   94.8800; depth[  1] =   65.9301;
            lat[  2] =   34.8145; lon[  2] =   94.8001; depth[  2] =   66.1805;
            lat[  3] =   34.7402; lon[  3] =   94.7204; depth[  3] =   66.4330;
            lat[  4] =   34.6658; lon[  4] =   94.6409; depth[  4] =   66.6898;
            lat[  5] =   34.5914; lon[  5] =   94.5615; depth[  5] =   66.9506;
            lat[  6] =   34.5170; lon[  6] =   94.4822; depth[  6] =   67.2155;
            lat[  7] =   34.4424; lon[  7] =   94.4031; depth[  7] =   67.4844;
            lat[  8] =   34.3679; lon[  8] =   94.3241; depth[  8] =   67.7573;
            lat[  9] =   34.2933; lon[  9] =   94.2453; depth[  9] =   68.0343;
            lat[ 10] =   34.2186; lon[ 10] =   94.1665; depth[ 10] =   68.3116;
            lat[ 11] =   34.1439; lon[ 11] =   94.0880; depth[ 11] =   68.5863;
            lat[ 12] =   34.0691; lon[ 12] =   94.0095; depth[ 12] =   68.8591;
            lat[ 13] =   33.9943; lon[ 13] =   93.9312; depth[ 13] =   69.1256;
            lat[ 14] =   33.9194; lon[ 14] =   93.8531; depth[ 14] =   69.3630;
            lat[ 15] =   33.8445; lon[ 15] =   93.7751; depth[ 15] =   69.5880;
            lat[ 16] =   33.7695; lon[ 16] =   93.6972; depth[ 16] =   69.8130;
            lat[ 17] =   33.6945; lon[ 17] =   93.6194; depth[ 17] =   70.0386;
            lat[ 18] =   33.6194; lon[ 18] =   93.5418; depth[ 18] =   70.2647;
            lat[ 19] =   33.5443; lon[ 19] =   93.4643; depth[ 19] =   70.4908;
            lat[ 20] =   33.4691; lon[ 20] =   93.3869; depth[ 20] =   70.7159;
            lat[ 21] =   33.3939; lon[ 21] =   93.3097; depth[ 21] =   70.9388;
            lat[ 22] =   33.3186; lon[ 22] =   93.2326; depth[ 22] =   71.1605;
            lat[ 23] =   33.2433; lon[ 23] =   93.1557; depth[ 23] =   71.3816;
            lat[ 24] =   33.1679; lon[ 24] =   93.0789; depth[ 24] =   71.6014;
            lat[ 25] =   33.0925; lon[ 25] =   93.0022; depth[ 25] =   71.8097;
            lat[ 26] =   33.0170; lon[ 26] =   92.9256; depth[ 26] =   72.0067;
            lat[ 27] =   32.9415; lon[ 27] =   92.8492; depth[ 27] =   72.1960;
            lat[ 28] =   32.8660; lon[ 28] =   92.7729; depth[ 28] =   72.3783;
            lat[ 29] =   32.7904; lon[ 29] =   92.6967; depth[ 29] =   72.5464;
            lat[ 30] =   32.7147; lon[ 30] =   92.6206; depth[ 30] =   72.6910;
            lat[ 31] =   32.6390; lon[ 31] =   92.5447; depth[ 31] =   72.8163;
            lat[ 32] =   32.5633; lon[ 32] =   92.4689; depth[ 32] =   72.9352;
            lat[ 33] =   32.4875; lon[ 33] =   92.3933; depth[ 33] =   73.0476;
            lat[ 34] =   32.4116; lon[ 34] =   92.3177; depth[ 34] =   73.1558;
            lat[ 35] =   32.3357; lon[ 35] =   92.2423; depth[ 35] =   73.2618;
            lat[ 36] =   32.2598; lon[ 36] =   92.1670; depth[ 36] =   73.3679;
            lat[ 37] =   32.1838; lon[ 37] =   92.0919; depth[ 37] =   73.4728;
            lat[ 38] =   32.1078; lon[ 38] =   92.0168; depth[ 38] =   73.5730;
            lat[ 39] =   32.0317; lon[ 39] =   91.9419; depth[ 39] =   73.6654;
            lat[ 40] =   31.9556; lon[ 40] =   91.8671; depth[ 40] =   73.7446;
            lat[ 41] =   31.8795; lon[ 41] =   91.7924; depth[ 41] =   73.7865;
            lat[ 42] =   31.8032; lon[ 42] =   91.7179; depth[ 42] =   73.8009;
            lat[ 43] =   31.7270; lon[ 43] =   91.6435; depth[ 43] =   73.8035;
            lat[ 44] =   31.6507; lon[ 44] =   91.5692; depth[ 44] =   73.7990;
            lat[ 45] =   31.5744; lon[ 45] =   91.4950; depth[ 45] =   73.7835;
            lat[ 46] =   31.4980; lon[ 46] =   91.4209; depth[ 46] =   73.7518;
            lat[ 47] =   31.4216; lon[ 47] =   91.3470; depth[ 47] =   73.7125;
            lat[ 48] =   31.3451; lon[ 48] =   91.2731; depth[ 48] =   73.6685;
            lat[ 49] =   31.2686; lon[ 49] =   91.1994; depth[ 49] =   73.6198;
            lat[ 50] =   31.1920; lon[ 50] =   91.1258; depth[ 50] =   73.5667;
            lat[ 51] =   31.1154; lon[ 51] =   91.0524; depth[ 51] =   73.5090;
            lat[ 52] =   31.0388; lon[ 52] =   90.9790; depth[ 52] =   73.4470;
            lat[ 53] =   30.9621; lon[ 53] =   90.9058; depth[ 53] =   73.3840;
            lat[ 54] =   30.8854; lon[ 54] =   90.8327; depth[ 54] =   73.3210;
            lat[ 55] =   30.8086; lon[ 55] =   90.7597; depth[ 55] =   73.2578;
            lat[ 56] =   30.7318; lon[ 56] =   90.6868; depth[ 56] =   73.1959;
            lat[ 57] =   30.6549; lon[ 57] =   90.6140; depth[ 57] =   73.0303;
            lat[ 58] =   30.5780; lon[ 58] =   90.5413; depth[ 58] =   72.8194;
            lat[ 59] =   30.5011; lon[ 59] =   90.4688; depth[ 59] =   72.6064;
            lat[ 60] =   30.4241; lon[ 60] =   90.3964; depth[ 60] =   72.3900;
            lat[ 61] =   30.3471; lon[ 61] =   90.3240; depth[ 61] =   72.1712;
            lat[ 62] =   30.2700; lon[ 62] =   90.2518; depth[ 62] =   71.9503;
            lat[ 63] =   30.1929; lon[ 63] =   90.1797; depth[ 63] =   71.7276;
            lat[ 64] =   30.1158; lon[ 64] =   90.1078; depth[ 64] =   71.5017;
            lat[ 65] =   30.0386; lon[ 65] =   90.0359; depth[ 65] =   71.2663;

            assertEquals(lat.length, actual[0].length);
            for (int i = 0; i < lat.length; ++i)
            {
                assertEquals(lat[i], actual[0][i] * rtd, 1e-4);
                assertEquals(lon[i], actual[1][i] * rtd, 1e-4);
                assertEquals(depth[i], actual[2][i], 1e-3);
            }
        }
    }

    @Test
    public void testGetGreatCirclePoints() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGreatCirclePoints()");
        double[][] actual = slbm.getGreatCirclePoints(30 * dtr, 90 * dtr,
                35 * dtr, 95 * dtr, 66);
        boolean choice = false;
        if (choice)
        {
            int n = actual[0].length;
            double[] lat = actual[0];
            double[] lon = actual[1];
            System.out.printf("double[] lat = new double[%d];%n", n);
            System.out.printf("double[] lon = new double[%d];%n", n);
            for (int i = 0; i < n; ++i)
                System.out.printf("lat[%3d] = %9.4f; lon[%3d] = %9.4f;%n", i,
                        lat[i] * rtd, i, lon[i] * rtd);
        }
        else
        {
            double[] lat = new double[66];
            double[] lon = new double[66];
            lat[  0] =   30.0000; lon[  0] =   90.0000;
            lat[  1] =   30.0784; lon[  1] =   90.0729;
            lat[  2] =   30.1567; lon[  2] =   90.1460;
            lat[  3] =   30.2350; lon[  3] =   90.2191;
            lat[  4] =   30.3133; lon[  4] =   90.2924;
            lat[  5] =   30.3915; lon[  5] =   90.3658;
            lat[  6] =   30.4697; lon[  6] =   90.4393;
            lat[  7] =   30.5478; lon[  7] =   90.5129;
            lat[  8] =   30.6259; lon[  8] =   90.5866;
            lat[  9] =   30.7040; lon[  9] =   90.6604;
            lat[ 10] =   30.7820; lon[ 10] =   90.7344;
            lat[ 11] =   30.8600; lon[ 11] =   90.8085;
            lat[ 12] =   30.9379; lon[ 12] =   90.8827;
            lat[ 13] =   31.0158; lon[ 13] =   90.9570;
            lat[ 14] =   31.0936; lon[ 14] =   91.0315;
            lat[ 15] =   31.1714; lon[ 15] =   91.1060;
            lat[ 16] =   31.2491; lon[ 16] =   91.1807;
            lat[ 17] =   31.3268; lon[ 17] =   91.2555;
            lat[ 18] =   31.4045; lon[ 18] =   91.3305;
            lat[ 19] =   31.4821; lon[ 19] =   91.4055;
            lat[ 20] =   31.5597; lon[ 20] =   91.4807;
            lat[ 21] =   31.6372; lon[ 21] =   91.5560;
            lat[ 22] =   31.7147; lon[ 22] =   91.6314;
            lat[ 23] =   31.7921; lon[ 23] =   91.7070;
            lat[ 24] =   31.8695; lon[ 24] =   91.7827;
            lat[ 25] =   31.9468; lon[ 25] =   91.8585;
            lat[ 26] =   32.0241; lon[ 26] =   91.9344;
            lat[ 27] =   32.1014; lon[ 27] =   92.0105;
            lat[ 28] =   32.1786; lon[ 28] =   92.0867;
            lat[ 29] =   32.2557; lon[ 29] =   92.1630;
            lat[ 30] =   32.3328; lon[ 30] =   92.2394;
            lat[ 31] =   32.4099; lon[ 31] =   92.3160;
            lat[ 32] =   32.4869; lon[ 32] =   92.3927;
            lat[ 33] =   32.5638; lon[ 33] =   92.4695;
            lat[ 34] =   32.6408; lon[ 34] =   92.5465;
            lat[ 35] =   32.7176; lon[ 35] =   92.6236;
            lat[ 36] =   32.7944; lon[ 36] =   92.7008;
            lat[ 37] =   32.8712; lon[ 37] =   92.7781;
            lat[ 38] =   32.9479; lon[ 38] =   92.8556;
            lat[ 39] =   33.0246; lon[ 39] =   92.9333;
            lat[ 40] =   33.1012; lon[ 40] =   93.0110;
            lat[ 41] =   33.1778; lon[ 41] =   93.0889;
            lat[ 42] =   33.2543; lon[ 42] =   93.1669;
            lat[ 43] =   33.3308; lon[ 43] =   93.2451;
            lat[ 44] =   33.4072; lon[ 44] =   93.3234;
            lat[ 45] =   33.4836; lon[ 45] =   93.4018;
            lat[ 46] =   33.5599; lon[ 46] =   93.4804;
            lat[ 47] =   33.6362; lon[ 47] =   93.5591;
            lat[ 48] =   33.7124; lon[ 48] =   93.6379;
            lat[ 49] =   33.7885; lon[ 49] =   93.7169;
            lat[ 50] =   33.8647; lon[ 50] =   93.7960;
            lat[ 51] =   33.9407; lon[ 51] =   93.8753;
            lat[ 52] =   34.0167; lon[ 52] =   93.9547;
            lat[ 53] =   34.0927; lon[ 53] =   94.0343;
            lat[ 54] =   34.1686; lon[ 54] =   94.1139;
            lat[ 55] =   34.2444; lon[ 55] =   94.1938;
            lat[ 56] =   34.3202; lon[ 56] =   94.2737;
            lat[ 57] =   34.3960; lon[ 57] =   94.3539;
            lat[ 58] =   34.4717; lon[ 58] =   94.4341;
            lat[ 59] =   34.5473; lon[ 59] =   94.5145;
            lat[ 60] =   34.6229; lon[ 60] =   94.5951;
            lat[ 61] =   34.6984; lon[ 61] =   94.6758;
            lat[ 62] =   34.7739; lon[ 62] =   94.7566;
            lat[ 63] =   34.8493; lon[ 63] =   94.8376;
            lat[ 64] =   34.9247; lon[ 64] =   94.9187;
            lat[ 65] =   35.0000; lon[ 65] =   95.0000;

            assertEquals(lat.length, actual[0].length);
            for (int i = 0; i < lat.length; ++i)
            {
                assertEquals(lat[i], actual[0][i] * rtd, 1e-4);
                assertEquals(lon[i], actual[1][i] * rtd, 1e-4);
            }
        }
    }

    @Test
    public void testGetGreatCirclePointsOnCenters() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGreatCirclePointsOnCenters()");
        double[][] actual = slbm.getGreatCirclePointsOnCenters(30 * dtr,
                90 * dtr, 35 * dtr, 95 * dtr, 66);
        boolean choice = false;
        if (choice)
        {
            int n = actual[0].length;
            double[] lat = actual[0];
            double[] lon = actual[1];
            System.out.printf("double[] lat = new double[%d];%n", n);
            System.out.printf("double[] lon = new double[%d];%n", n);
            for (int i = 0; i < n; ++i)
                System.out.printf("lat[%3d] = %9.4f; lon[%3d] = %9.4f;%n", i,
                        lat[i] * rtd, i, lon[i] * rtd);
        }
        else
        {
            double[] lat = new double[66];
            double[] lon = new double[66];
            lat[  0] =   30.0386; lon[  0] =   90.0359;
            lat[  1] =   30.1158; lon[  1] =   90.1078;
            lat[  2] =   30.1929; lon[  2] =   90.1797;
            lat[  3] =   30.2700; lon[  3] =   90.2518;
            lat[  4] =   30.3471; lon[  4] =   90.3240;
            lat[  5] =   30.4241; lon[  5] =   90.3964;
            lat[  6] =   30.5011; lon[  6] =   90.4688;
            lat[  7] =   30.5780; lon[  7] =   90.5413;
            lat[  8] =   30.6549; lon[  8] =   90.6140;
            lat[  9] =   30.7318; lon[  9] =   90.6868;
            lat[ 10] =   30.8086; lon[ 10] =   90.7597;
            lat[ 11] =   30.8854; lon[ 11] =   90.8327;
            lat[ 12] =   30.9621; lon[ 12] =   90.9058;
            lat[ 13] =   31.0388; lon[ 13] =   90.9790;
            lat[ 14] =   31.1154; lon[ 14] =   91.0524;
            lat[ 15] =   31.1920; lon[ 15] =   91.1258;
            lat[ 16] =   31.2686; lon[ 16] =   91.1994;
            lat[ 17] =   31.3451; lon[ 17] =   91.2731;
            lat[ 18] =   31.4216; lon[ 18] =   91.3470;
            lat[ 19] =   31.4980; lon[ 19] =   91.4209;
            lat[ 20] =   31.5744; lon[ 20] =   91.4950;
            lat[ 21] =   31.6507; lon[ 21] =   91.5692;
            lat[ 22] =   31.7270; lon[ 22] =   91.6435;
            lat[ 23] =   31.8032; lon[ 23] =   91.7179;
            lat[ 24] =   31.8795; lon[ 24] =   91.7924;
            lat[ 25] =   31.9556; lon[ 25] =   91.8671;
            lat[ 26] =   32.0317; lon[ 26] =   91.9419;
            lat[ 27] =   32.1078; lon[ 27] =   92.0168;
            lat[ 28] =   32.1838; lon[ 28] =   92.0919;
            lat[ 29] =   32.2598; lon[ 29] =   92.1670;
            lat[ 30] =   32.3357; lon[ 30] =   92.2423;
            lat[ 31] =   32.4116; lon[ 31] =   92.3177;
            lat[ 32] =   32.4875; lon[ 32] =   92.3933;
            lat[ 33] =   32.5633; lon[ 33] =   92.4689;
            lat[ 34] =   32.6390; lon[ 34] =   92.5447;
            lat[ 35] =   32.7147; lon[ 35] =   92.6206;
            lat[ 36] =   32.7904; lon[ 36] =   92.6967;
            lat[ 37] =   32.8660; lon[ 37] =   92.7729;
            lat[ 38] =   32.9415; lon[ 38] =   92.8492;
            lat[ 39] =   33.0170; lon[ 39] =   92.9256;
            lat[ 40] =   33.0925; lon[ 40] =   93.0022;
            lat[ 41] =   33.1679; lon[ 41] =   93.0789;
            lat[ 42] =   33.2433; lon[ 42] =   93.1557;
            lat[ 43] =   33.3186; lon[ 43] =   93.2326;
            lat[ 44] =   33.3939; lon[ 44] =   93.3097;
            lat[ 45] =   33.4691; lon[ 45] =   93.3869;
            lat[ 46] =   33.5443; lon[ 46] =   93.4643;
            lat[ 47] =   33.6194; lon[ 47] =   93.5418;
            lat[ 48] =   33.6945; lon[ 48] =   93.6194;
            lat[ 49] =   33.7695; lon[ 49] =   93.6972;
            lat[ 50] =   33.8445; lon[ 50] =   93.7751;
            lat[ 51] =   33.9194; lon[ 51] =   93.8531;
            lat[ 52] =   33.9943; lon[ 52] =   93.9312;
            lat[ 53] =   34.0691; lon[ 53] =   94.0095;
            lat[ 54] =   34.1439; lon[ 54] =   94.0880;
            lat[ 55] =   34.2186; lon[ 55] =   94.1665;
            lat[ 56] =   34.2933; lon[ 56] =   94.2453;
            lat[ 57] =   34.3679; lon[ 57] =   94.3241;
            lat[ 58] =   34.4424; lon[ 58] =   94.4031;
            lat[ 59] =   34.5170; lon[ 59] =   94.4822;
            lat[ 60] =   34.5914; lon[ 60] =   94.5615;
            lat[ 61] =   34.6658; lon[ 61] =   94.6409;
            lat[ 62] =   34.7402; lon[ 62] =   94.7204;
            lat[ 63] =   34.8145; lon[ 63] =   94.8001;
            lat[ 64] =   34.8887; lon[ 64] =   94.8800;
            lat[ 65] =   34.9629; lon[ 65] =   94.9600;

            assertEquals(lat.length, actual[0].length);
            for (int i = 0; i < lat.length; ++i)
            {
                assertEquals(lat[i], actual[0][i] * rtd, 1e-4);
                assertEquals(lon[i], actual[1][i] * rtd, 1e-4);
            }
        }
    }

    @Test
    public void testGetTravelTimeUncertainty() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetTravelTimeUncertainty()");
        assertEquals(1.249868, slbm.getTravelTimeUncertainty(), 1e-4);
    }

    @Test
    public void testGetTravelTimeUncertaintyStringDouble() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetTravelTimeUncertaintyStringDouble()");
        assertEquals(1.1975, slbm.getTravelTimeUncertainty("Pn", 5 * dtr), 1e-4);
        assertEquals(1.6370, slbm.getTravelTimeUncertainty("Sn", 5 * dtr), 1e-4);
        assertEquals(1.5000, slbm.getTravelTimeUncertainty("Pg", 1 * dtr), 1e-4);
        assertEquals(1.5260, slbm.getTravelTimeUncertainty("Lg", 1 * dtr), 1e-4);
    }

    @Test
    public void testGetZhaoParameters() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetZhaoParameters()");
        //System.out.println(slbm.getZhaoParameters());
        String expected = "Vm=8.0868  Gm=0.001527  H=12.043  C=0.000347018  Cm=0.000347433  udSign=0";
        String actual = slbm.getZhaoParameters().toString();
        assertEquals(expected, actual);
    }

    // @Test
    public void testGetPgLgComponents() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetPgLgComponents()");
        createGreatCircle(slbm, "Lg");
        double[] actual = getDoubles(slbm.getPgLgComponents(), false);
        createGreatCircle(slbm, "Pn");

        double[] expected = new double[] { 209.485360, 203.375499, 209.485360,
                0.276803, 0.286625, 6346.797398, 6351.891426 };

        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-3);
    }

    @Test
    public void testGetNodeNeighbors() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetNodeNeighbors()");
        int[] actual = getInts(slbm.getNodeNeighbors(57), false);
        int[] expected = new int[] {13070, 13071, 13192, 13350, 20824, 20825};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i]);

    }

    @Test
    public void testGetActiveNodeNeighbors() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeNeighbors()");
        // depends on slbm.initializeActiveNodes(28*dtr, 80*dtr, 32*dtr, 105*dtr);

        int activeNodeId = slbm.getActiveNodeId(57);

        int[] actual = getInts(slbm.getActiveNodeNeighbors(activeNodeId), false);

        int[] expected = new int[] {23, 24, 33, 46, 51, 52};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i]);

        //		for (int e : expected)
        //		{
        //			GridProfile node = slbm.getActiveNodeData(e);
        //			System.out.printf("%10.4f %10.4f%n", node.lat*rtd, node.lon*rtd);
        //		}
    }

    @Test
    public void testGetNodeSeparation() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetNodeSeparation()");

        int[] nodes = slbm.getNodeNeighbors(57);
        assertEquals(6, nodes.length);

        for (int i : nodes)
            assertTrue(slbm.getNodeSeparation(57, i) * rtd < 1.5);
    }

    @Test
    public void testGetNodeAzimuth() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetNodeAzimuth()");

        //System.out.println(slbm.getNodeAzimuth(57, 819)*rtd);
        assertEquals(62.548568558829935, slbm.getNodeAzimuth(57, 819) * rtd, 1e-1);
    }

    @Test
    public void testGetNodeHitCount() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetNodeHitCount()");
        slbm.clearHitCount();
        assertEquals(0, slbm.getNodeHitCount(13338));
        slbm.getWeights();
        assertEquals(1, slbm.getNodeHitCount(13338));
        slbm.getWeights();
        assertEquals(2, slbm.getNodeHitCount(13338));
    }

    @Test
    public void testGetNActiveNodes() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetNActiveNodes()");

        assertEquals(147, slbm.getNActiveNodes());
    }

    @Test
    public void testGetGridNodeId() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetGridNodeId()");

        int gridNodeId = 57;
        int activeNodeId = slbm.getActiveNodeId(gridNodeId);
        System.out.printf("Grid node id = %d activeNodeId = %d%n", gridNodeId, activeNodeId);

        assertEquals(gridNodeId, slbm.getGridNodeId(activeNodeId));
    }

    @Test
    public void testGetActiveNodeId()
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeId()");
        int activeNodeId = 10;
        int gridNodeId = slbm.getGridNodeId(activeNodeId);
        //System.out.printf("Grid node id = %d activeNodeId = %d%n", gridNodeId, activeNodeId);

        assertEquals(activeNodeId, slbm.getActiveNodeId(gridNodeId));
    }

    @Test
    public void testGetActiveNodeWeights() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeWeights()");

        GridWeight weights = slbm.getActiveNodeWeights();

        // for (int i=0; i<weights.node.length; ++i)
        // {
        // GridProfile node = slbm.getGridData(weights.node[i]);
        // System.out.printf("%10.4f %10.4f%n", node.lat*rtd, node.lon*rtd);
        // }

        ArrayList<String> actual = getRecords(weights.toString(), false);

        ArrayList<String> expected = new ArrayList<String>(20);
        expected.add("Grid Node Weights: ");
        expected.add("");
        expected.add("  Node     Weight");
        expected.add("    -1    87.8662");
        expected.add("    -1    11.4329");
        expected.add("    -1     0.0432");
        expected.add("    -1     9.0897");
        expected.add("    -1     0.0105");
        expected.add("    -1     2.1861");
        expected.add("   123    65.2155");
        expected.add("    -1    24.3234");
        expected.add("    99    80.4458");
        expected.add("    43    12.9487");
        expected.add("    45    86.4536");
        expected.add("   125     8.7520");
        expected.add("    44    56.9541");
        expected.add("    12    30.8145");
        expected.add("    46    50.1971");
        expected.add("    23     0.4145");
        expected.add("    85     0.0077");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

        // the sum of the weights should be equal to the headwave distance
        // in km.
        assertEquals(weights.getSum(), slbm.getHeadwaveDistanceKm(), 1e-2);
    }

    @Test
    public void testGetActiveNodeData() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeData()");

        ArrayList<String> actual = getRecords(slbm.getActiveNodeData(0).toString(), false);

        ArrayList<String> expected = new ArrayList<String>(18);
        expected.add("GridProfile:");
        expected.add("");
        expected.add("  Node ID  :          0");
        expected.add("  Latitude :    30.5474");
        expected.add("  Longitude:    89.5330");
        expected.add("");
        expected.add("     Depth        Thick      P Vel      S Vel");
        expected.add("   -5.522179     0.0000     1.5000     0.0000");
        expected.add("   -5.522179     0.1001     2.5013     1.1987");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081     0.0000     0.0000     0.0000");
        expected.add("   -5.422081    24.9502     6.0032     3.4582");
        expected.add("   19.528114     0.0000     6.4034     3.6960");
        expected.add("   19.528114    26.7808     6.1350     3.5024");
        expected.add("   46.308876    26.7813     7.1038     3.8958");
        expected.add("   73.090126                8.1063     4.5955");
        expected.add("               P Grad     S Grad");
        expected.add("             0.000720  -0.000055");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testGetNGridNodes()
    {
        if (verbosity > 0)
            System.out.println("testGetNGridNodes()");

        assertEquals(40962, slbm.getNGridNodes());
    }

    @Test
    public void testGetNHeadWavePoints()
    {
        if (verbosity > 0)
            System.out.println("testGetNHeadWavePoints()");

        assertEquals(66, slbm.getNHeadWavePoints());
    }

    @Test
    public void testGetNodeNeighborInfo()
    {
        if (verbosity > 0)
            System.out.println("testGetNodeNeighborInfo()");

        ArrayList<String> actual = getRecords(slbm.getNodeNeighborInfo(57).toString(), false);

        ArrayList<String> expected = new ArrayList<String>(9);
        expected.add("QueryNeighborInfo: ");
        expected.add("  Node :      57");
        expected.add("  Neighbor    Distance    Azimuth");
        expected.add("  13070     1.0258    11.9271");
        expected.add("  13071     1.1554   -44.5354");
        expected.add("  13192     0.9912   -99.5861");
        expected.add("  13350     0.9912    80.4139");
        expected.add("  20824     1.1554  -154.6368");
        expected.add("  20825     1.0258   148.9007");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testGetActiveNodeNeighborInfo()
    {
        if (verbosity > 0)
            System.out.println("testGetActiveNodeNeighborInfo()");

        ArrayList<String> actual = getRecords(slbm.getActiveNodeNeighborInfo(0).toString(), false);

        ArrayList<String> expected = new ArrayList<String>(9);
        expected.add("QueryNeighborInfo: ");
        expected.add("  Node :       0");
        expected.add("  Neighbor    Distance    Azimuth");
        expected.add("     23     1.0258    11.9271");
        expected.add("     24     1.1554   -44.5354");
        expected.add("     33     0.9912   -99.5861");
        expected.add("     46     0.9912    80.4139");
        expected.add("     51     1.1554  -154.6368");
        expected.add("     52     1.0258   148.9007");

        assertEquals(expected.size(), actual.size());
        for (int i=0; i<expected.size(); ++i)
            assertEquals(expected.get(i), actual.get(i));

    }

    @Test
    public void testGetCHMax()
    {
        if (verbosity > 0)
            System.out.println("testGetCHMax()");

        assertEquals(0.2, slbm.getCHMax(), 1e-6);

    }

    @Test
    public void testSetCHMax()
    {
        if (verbosity > 0)
            System.out.println("testSetCHMax()");

        slbm.setCHMax(0.3);
        assertEquals(0.3, slbm.getCHMax(), 1e-6);

        slbm.setCHMax(0.2);
        assertEquals(0.2, slbm.getCHMax(), 1e-6);

    }

    @Test
    public void testGetAverageMantleVelocity()
    {
        if (verbosity > 0)
            System.out.println("testGetAverageMantleVelocity()");

        //		System.out.printf("%1.6f  %1.6f%n",
        //				slbm.getAverageMantleVelocity(SlbmInterface.PWAVE),
        //				slbm.getAverageMantleVelocity(SlbmInterface.SWAVE));

        assertEquals(8.104615, slbm.getAverageMantleVelocity(SlbmInterface.PWAVE), 1e-6);
        assertEquals(4.435126, slbm.getAverageMantleVelocity(SlbmInterface.SWAVE), 1e-6);

    }

    @Test
    public void testSetAverageMantleVelocity()
    {
        if (verbosity > 0)
            System.out.println("testSetAverageMantleVelocity()");

        double p = slbm.getAverageMantleVelocity(SlbmInterface.PWAVE);
        double s = slbm.getAverageMantleVelocity(SlbmInterface.SWAVE);

        slbm.setAverageMantleVelocity(SlbmInterface.PWAVE, 200.);
        slbm.setAverageMantleVelocity(SlbmInterface.SWAVE, 100.);

        assertEquals(200., slbm.getAverageMantleVelocity(SlbmInterface.PWAVE), 1e-6);
        assertEquals(100., slbm.getAverageMantleVelocity(SlbmInterface.SWAVE), 1e-6);

        slbm.setAverageMantleVelocity(SlbmInterface.PWAVE, p);
        slbm.setAverageMantleVelocity(SlbmInterface.SWAVE, s);

        assertEquals(8.104615, slbm.getAverageMantleVelocity(SlbmInterface.PWAVE), 1e-6);
        assertEquals(4.435126, slbm.getAverageMantleVelocity(SlbmInterface.SWAVE), 1e-6);
    }

    @Test
    public void testGetFractionActive()
    {
        if (verbosity > 0)
            System.out.println("testGetFractionActive()");

        //System.out.printf("%1.6f%n", slbm.getFractionActive());
        assertEquals(0.545455, slbm.getFractionActive(), 1e-6);

    }

    @Test
    public void testSetMaxDistance()
    {
        if (verbosity > 0)
            System.out.println("testSetMaxDistance()");

        slbm.setMaxDistance(25. * dtr);
        assertEquals(25., slbm.getMaxDistance() * rtd, 1e-6);

        slbm.setMaxDistance(15. * dtr);
        assertEquals(15., slbm.getMaxDistance() *rtd, 1e-6);


    }

    @Test
    public void testGetMaxDistance()
    {
        if (verbosity > 0)
            System.out.println("testGetMaxDistance()");

        //System.out.printf("%1.6f%n", slbm.getMaxDistance()*rtd);
        assertEquals(15., slbm.getMaxDistance()*rtd, 1e-6);

    }

    @Test
    public void testSetMaxDepth()
    {
        if (verbosity > 0)
            System.out.println("testSetMaxDepth()");

        slbm.setMaxDepth(300.);
        assertEquals(300., slbm.getMaxDepth(), 1e-6);

        slbm.setMaxDepth(200.);
        assertEquals(200., slbm.getMaxDepth(), 1e-6);

    }

    @Test
    public void testGetMaxDepth()
    {
        if (verbosity > 0)
            System.out.println("testGetMaxDepth()");

        //System.out.printf("%1.6f%n", slbm.getMaxDepth());
        assertEquals(200., slbm.getMaxDepth(), 1e-6);

    }

    @Test
    public void testGet_dtt_dlat() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGet_dtt_dlat()");

        //System.out.printf("%1.6f%n", slbm.get_dtt_dlat());
        assertEquals(572.133112, slbm.get_dtt_dlat(), 1e-2);

    }

    @Test
    public void testGet_dtt_dlon() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGet_dtt_dlon()");

        //System.out.printf("%1.6f%n", slbm.get_dtt_dlon());
        assertEquals(508.865534, slbm.get_dtt_dlon(), 1e-2);

    }

    @Test
    public void testGet_dtt_ddepth() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGet_dtt_ddepth()");

        //System.out.printf("%1.6f%n", slbm.get_dtt_ddepth());
        assertEquals(-0.109799, slbm.get_dtt_ddepth(), 1e-2);

    }

    @Test
    public void testGetSlowness() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSlowness()");

        //System.out.printf("%1.6f%n", slbm.getSlowness());
        assertEquals(763.791441, slbm.getSlowness(), 1e-2);

    }

    @Test
    public void testGetSlownessUncertainty() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSlownessUncertainty()");

        //System.out.printf("%1.6f%n", slbm.getSlownessUncertainty());
        assertEquals(14.656260, slbm.getSlownessUncertainty(), 1e-2);

    }

    @Test
    public void testGetSlownessUncertaintyStringDouble() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetSlownessUncertaintyStringDouble()");

        //System.out.printf("%1.6f%n", slbm.getSlownessUncertainty("Pn", 6.*dtr));
        assertEquals(14.656260, slbm.getSlownessUncertainty("Pn", 6.*dtr), 1e-2);

    }

    @Test
    public void testMovePoint()
    {
        if (verbosity > 0)
            System.out.println("testMovePoint()");

        double[] point = slbm.movePoint(30*dtr, 60*dtr, 10*dtr, 60*dtr);
        point[0] *= rtd;
        point[1] *= rtd;
        //System.out.println(Arrays.toString(point));
        assertEquals(34.5988334793662, point[0], 1e-6);
        assertEquals(70.5037575698728, point[1], 1e-6);
    }

    @Test
    public void testGetDistAz()
    {
        if (verbosity > 0)
            System.out.println("testGetDistAz()");

        double[] distaz = slbm.getDistAz(30*dtr, 60*dtr, 34.5988334793662*dtr, 70.5037575698728 *dtr, -999.);
        distaz[0] *= rtd;
        distaz[1] *= rtd;
        //System.out.println(Arrays.toString(distaz));
        assertEquals(10., distaz[0], 1e-6);
        assertEquals(60., distaz[1], 1e-6);

    }

    @Test
    public void testGetPiercePointSource()
    {
        if (verbosity > 0)
            System.out.println("testGetPiercePointSource()");

        double[] actual = getDoubles(slbm.getPiercePointSource(), false);

        //System.out.printf("%1.6f, %1.6f, %1.4f%n", actual[0], actual[1], actual[2]);

        double[] expected = new double[] {0.599890, 1.646327, 67.7451};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-3);
    }

    @Test
    public void testGetPiercePointReceiver()
    {
        if (verbosity > 0)
            System.out.println("testGetPiercePointReceiver()");

        double[] actual = getDoubles(slbm.getPiercePointReceiver(), false);

        //System.out.printf("%1.6f, %1.6f, %1.4f%n", actual[0], actual[1], actual[2]);

        double[] expected = new double[] {0.535848, 1.582287, 73.1585};

        assertEquals(expected.length, actual.length);
        for (int i=0; i<expected.length; ++i)
            assertEquals(expected[i], actual[i], 1e-3);
    }

    @Test
    public void testGetDelDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetDelDistance()");

        //System.out.printf("%1.6f radians%n", slbm.getDelDistance());
        assertEquals(0.001, slbm.getDelDistance(), 1e-6);

    }

    @Test
    public void testSetDelDistance() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testSetDelDistance()");

        slbm.setDelDistance(0.002);
        assertEquals(0.002, slbm.getDelDistance(), 1e-6);

        slbm.setDelDistance(0.001);
        assertEquals(0.001, slbm.getDelDistance(), 1e-6);

    }

    @Test
    public void testGetDelDepth() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testGetDelDepth()");

        //System.out.printf("%1.6f km%n", slbm.getDelDepth());
        assertEquals(0.1, slbm.getDelDepth(), 1e-6);

    }

    @Test
    public void testSetDelDepth() throws SLBMException
    {
        if (verbosity > 0)
            System.out.println("testSetDelDepth()");

        slbm.setDelDepth(0.2);
        assertEquals(0.2, slbm.getDelDepth(), 1e-6);

        slbm.setDelDepth(0.1);
        assertEquals(0.1, slbm.getDelDepth(), 1e-6);

    }

    @Test
    public void testSetPathIncrement()
    {
        if (verbosity > 0)
            System.out.println("testSetPathIncrement()");

        double x = slbm.getPathIncrement();

        slbm.setPathIncrement(0.2*dtr);
        assertEquals(0.2, slbm.getPathIncrement()*rtd, 1e-6);

        slbm.setPathIncrement(x);
        assertEquals(0.1, slbm.getPathIncrement()*rtd, 1e-6);

    }

    @Test
    public void testGetPathIncrement()
    {
        if (verbosity > 0)
            System.out.println("testGetPathIncrement()");

        //System.out.printf("%1.6f%n", slbm.getPathIncrement()*rtd);
        assertEquals(0.1, slbm.getPathIncrement()*rtd, 1e-6);

    }

    private static ArrayList<String> getRecords(String s, boolean print)
    {
        ArrayList<String> records = new ArrayList<String>(1000);
        Scanner input = new Scanner(s);
        while (input.hasNext())
            records.add(input.nextLine());

        if (print)
        {
            System.out.println();
            System.out.printf("ArrayList<String> expected = new ArrayList<String>(%d);%n",
                    records.size());
            for (String x : records)
                System.out.printf("expected.add(\"%s\");%n", x);

            System.out.println();
            System.out .println("assertEquals(expected.size(), actual.size());");
            System.out.println("for (int i=0; i<expected.size(); ++i)");
            System.out .println("   assertEquals(expected.get(i), actual.get(i));");
            System.out.println();
        }
        return records;
    }

    private static int[] getInts(int[] values, boolean print)
    {
        if (print)
        {
            System.out.print("int[] expected = new int[] {");
            for (int i = 0; i < values.length; ++i)
                if (i == 0)
                    System.out.printf("%d", values[i]);
                else
                    System.out.printf(", %d", values[i]);
            System.out.println("};");
            System.out.println();
            System.out.println("assertEquals(expected.length, actual.length);");
            System.out.println("for (int i=0; i<expected.length; ++i)");
            System.out.println("   assertEquals(expected[i], actual[i]);");
            System.out.println();
        }
        return values;
    }

    private static double[] getDoubles(double[] values, boolean print)
    {
        if (print)
        {
            System.out.print("double[] expected = new double[] {");
            for (int i = 0; i < values.length; ++i)
            {
                if (i == 0)
                    System.out.printf("%1.6f", values[i]);
                else
                    System.out.printf(", %1.6f", values[i]);
            }
            System.out.println("};");
            System.out.println();
            System.out.println("assertEquals(expected.length, actual.length);");
            System.out.println("for (int i=0; i<expected.length; ++i)");
            System.out
            .println("   assertEquals(expected[i], actual[i], 1e-3);");
            System.out.println();
            System.out.printf("assertEquals(%1.6f, getSum(actual), 1e-4);%n",
                    getSum(values));
            System.out.println();
        }
        return values;
    }

    private static double getSum(double[] values)
    {
        double sum = 0;
        for (double d : values)
            sum += d;
        return sum;
    }

}
