#!/bin/bash

cp -rv doc ../../SLBM_JNI/java/SlbmInterface/
