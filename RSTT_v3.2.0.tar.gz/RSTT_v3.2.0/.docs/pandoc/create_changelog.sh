#!/bin/bash
# quick script to generate a changelog.html from the changelog.md

# set the title string
titlestr=Changelog

# pandoc command to compile changelog.md to changelog.html
echo $titlestr
pandoc -s --self-contained --toc --metadata=title:"$titlestr" \
	--css=normalize.css --css=sakura.css --css=pandoc.css --highlight-style=pygments \
	--from=markdown --to=html --output=../../changelog.html ../../changelog.md
