#!/bin/bash
# quick script to generate a readme.html from the readme.md

# get the title string "RSTT vX.Y.Z User Manual"
titlestr=$(grep -E "User Manual" ../../readme.md)

# pandoc command to compile readme.md to readme.html
echo $titlestr
pandoc -s --self-contained --toc --metadata=title:"$titlestr" \
	--css=normalize.css --css=sakura.css --css=pandoc.css --highlight-style=pygments \
	--from=markdown --to=html --output=../../readme.html ../../readme.md
