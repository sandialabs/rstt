#!/bin/bash

# doxygen produces html files with "~" in the name. while this is OK offline, it
# doesn't play well with many webservers. this script replaces all
# "...~.html" with "...-.html"

# navigate to rstt main folder
cd ../..
RSTT_HOME=$PWD

# GeoTessCPP
cd GeoTessCPP/doc/html  # navigate to folder
for file in $(ls *~.html); do mv -v $file ${file/\~/-}; done  # rename ~.html to -.html
grep -l '~.html' *.* | xargs sed -i.tmp 's/~.html/-.html/g'  #replace all mentions of ~.html with -.html
rm -v *.tmp  # remove .tmp files from sed
cd $RSTT_HOME

# SLBM
cd SLBM/doc/html  # navigate to folder
for file in $(ls *~.html); do mv -v $file ${file/\~/-}; done  # rename ~.html to -.html
grep -l '~.html' *.* | xargs sed -i.tmp 's/~.html/-.html/g'  #replace all mentions of ~.html with -.html
rm -v *.tmp  # remove .tmp files from sed
cd $RSTT_HOME
