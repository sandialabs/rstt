#!/usr/bin/env python

"""RSTT Python module installation script.

This allows the RSTT python module tobe installed via

    >>> python3 /path/to/rstt/setup.py
    
    or

    >>> pip install /path/to/rstt
"""

#-----------------------------------------
# initialization
#-----------------------------------------

# import statements
import setuptools  # setup script
import sysconfig   # external library suffix
import shutil      # file operations
import glob        # filename wildcards
import os          # get current directory

# use the entire readme as the long description
with open("README.md", 'r') as f:
    long_description = f.read()


#-----------------------------------------
# setup script
#-----------------------------------------

# main setup script
setuptools.setup(
    
    # simple metadata
    name="rstt",
    version="3.2.0",
    author="Brian A. Young",
    author_email="byoung@sandia.gov",
    description="Python interface to the RSTT software",
    long_description=long_description,
    long_description_content_type='text/markdown',
    url="https://www.sandia.gov/rstt/",

    # list some keywords (https://pypi.org/classifiers/)
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: C++',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering'
    ],

    # let setuptools figure out all the packages inside this module
    packages=setuptools.find_packages(),

    # python dependencies
    python_requires='>=3.6',

    # additional files to put in the package main directory
    include_package_data = True
    
)
