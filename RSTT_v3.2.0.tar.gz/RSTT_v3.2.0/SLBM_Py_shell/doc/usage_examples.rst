Usage examples
==============

Below is a simple example demonstrating how to use the `rstt` Python module.

.. code-block:: python

    # declare the relative path to the model file we're going to be using
    modelPath = "example.geotess"

    # choose an arbitrary phase (Pn, Pg, Sn, or Lg)
    phase = "Pn"

    # arbitrary source (Meteor Crater, AZ)
    srcLatDeg =   35.0274  # latitude (degrees)
    srcLonDeg = -111.0228  # longitude (degrees)
    srcDepKm  =    1.2345  # depth (km)

    # arbitrary receiver (Albuquerque, NM)
    rcvLatDeg =   35.1053  # latitude (degrees)
    rcvLonDeg = -106.6294  # longitude (degrees)
    rcvDepKm  =   -1.6000  # depth (km)

    # convert lat/lon from degrees to radians
    srcLatRad = rstt.deg2rad(srcLatDeg)
    srcLonRad = rstt.deg2rad(srcLonDeg)
    rcvLatRad = rstt.deg2rad(rcvLatDeg)
    rcvLonRad = rstt.deg2rad(rcvLonDeg)

    # instantiate an RSTT object
    slbm = rstt.SlbmInterface()

    # load the velocity model
    slbm.loadVelocityModel(modelPath)

    # create a great circle from source to the receiver
    slbm.createGreatCircle(phase,
        srcLatRad, srcLonRad, srcDepKm,
        rcvLatRad, rcvLonRad, rcvDepKm)

    # get the distance and travel time from source --> receiver
    travelTimeSec = slbm.getTravelTime()   # compute travel time (sec)
    distRad       = slbm.getDistance()     # compute distance (rad)
    distDeg       = rstt.rad2deg(distRad)  # convert radians --> degrees

    # get the travel time uncertainty
    travelTimeUncertSec = slbm.getTravelTimeUncertainty()

    # print our results
    print(
        "RSTT Usage Example\n" +
        "--------------------------------\n" +
        "Distance:       {:7.4f} deg\n".format(distDeg) +
        "Travel Time:    {:7.4f} sec\n".format(travelTimeSec) +
        "Uncertainty:    {:7.4f} sec\n".format(travelTimeUncertSec) +
        )