Regional Seismic Travel Time (RSTT)
===================================

Welcome to the RSTT documentation. Please navigate using the sidebar on the
left.

.. toctree::
   :hidden:
   :maxdepth: 2

   self
   usage_examples
   rstt/index
   genindex