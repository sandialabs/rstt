rstt.utils
==========

.. automodule:: rstt.utils

    .. rubric:: Functions
    .. autofunction:: rstt.utils.deg2rad
    .. autofunction:: rstt.utils.rad2deg
