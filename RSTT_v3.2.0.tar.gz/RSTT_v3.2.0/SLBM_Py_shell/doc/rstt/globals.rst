rstt.globals
============

.. automodule:: rstt.globals

    .. rubric:: Attributes
    .. autoattribute:: rstt.globals.version
    .. autoattribute:: rstt.globals.DEG_PER_RAD
        :annotation: = 180 / pi
    .. autoattribute:: rstt.globals.RAD_PER_DEG
        :annotation: = pi / 180
    .. autoattribute:: rstt.globals.PWAVE
    .. autoattribute:: rstt.globals.SWAVE
    .. autoattribute:: rstt.globals.WATER
    .. autoattribute:: rstt.globals.SEDIMENT1
    .. autoattribute:: rstt.globals.SEDIMENT2
    .. autoattribute:: rstt.globals.SEDIMENT3
    .. autoattribute:: rstt.globals.UPPER_CRUST
    .. autoattribute:: rstt.globals.MIDDLE_CRUST_N
    .. autoattribute:: rstt.globals.MIDDLE_CRUST_G
    .. autoattribute:: rstt.globals.LOWER_CRUST
    .. autoattribute:: rstt.globals.MANTLE
    .. autoattribute:: rstt.globals.NLAYERS
    .. autoattribute:: rstt.globals.Pn
    .. autoattribute:: rstt.globals.Sn
    .. autoattribute:: rstt.globals.Pg
    .. autoattribute:: rstt.globals.Lg
    .. autoattribute:: rstt.globals.TT
    .. autoattribute:: rstt.globals.SH
    .. autoattribute:: rstt.globals.AZ

    .. rubric:: Functions
    .. autofunction:: rstt.globals.attributes
    .. autofunction:: rstt.globals.phases
