RSTT Module
===========

.. toctree::
   :maxdepth: 2
   :caption: Submodules

   globals
   utils
   slbminterface
   
Note: All of the submodules are imported into the main `rstt` namespace. As
such, rather than invoking each command through its full namespace, such as

.. code-block:: python
    
    rstt.globals.PWAVE
    rstt.utils.deg2rad(180)
    rstt.slbminterface.SlbmInterface()

it is sufficient to type

.. code-block:: python
    
    rstt.PWAVE
    rstt.deg2rad(180)
    rstt.SlbmInterface()

