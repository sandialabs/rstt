RSTT_NOGS stands for Regional Seismic Travel Time _ NOde Get and Set

Summary:
RSTT_NOGS are UNIX command-line programs that allow users to get and set velocity profiles at RSTT tessellation nodes.  Usage for RSTT.GetNodes and RSTT.SetNodes is returned if no arguments are provided. RSTT.GetNodes returns velocity profiles for either nodes within a latitude, longitude box or nodes specified by integer ID.  RSTT.SetNodes updates velocity profiles using a formatted flat file.

Code Lineage
RSTT_NOGS is a java code written by me at Lawrence Livermore National Laboratory.  RSTT_NODES makes use of the Seismic Location Baseline Model (SLBM) code developed by Sandy Ballard at Sandia National Laboratories.

Supporting Files:
I have provided kml files that display nodes for the na1010pn (ca. Oct 2010) model and the RSTT2.3 model (ca. Jan 2012) in GoogleEarth.  Clicking on a node will show that latitude, longitude, and nodeID. 

Installation:
Installation is as easy as untarring the RSTT_NUGS.tar file. The RSTT_NOGS codes are in the RSTT_NUGS/RSTT_NOGS.jar file.  The source codes are provided for transparency and to provide a tutorial if users who want to write their own codes that utilize the SLBM code base.

Path Configuration:
This is the trickiest part of using the code.  First, you need to install the Sandia SLBM_Root code (current version is SLBM_Root_2.8.2). Compilation of the code (simple make command) will produce the following files in SLBM_Root_2.8.2/lib: slbmjni.jar, libslbmjni.jnilib, and libslbm.dylib.  You will need to set the following paths in your UNIX environment so that java will link to SLBM (C++/JNI) libs:
setenv SLBM_HOME <full path to SLBM_ROOT>
setenv DYLD_LIBRARY_PATH ${DYLD_LIBRARY_PATH}:${SLBM_HOME}/lib
Of course the command will be something like export SLBM_HOME=É for the bash environment. Then I recommend setting the java CLASSPATH on the command line. e.g. 
java -Djava.library.path="$SLBM_ROOT/lib" -cp "$SLBM_ROOT/RSTT_NOGS/RSTT_NOGS.jar:$SLBM_ROOT/lib/slbmjni.jar" RSTT.GetNodes
java -Djava.library.path="$SLBM_ROOT/lib" -cp "$SLBM_ROOT/RSTT_NOGS/RSTT_NOGS.jar:$SLBM_ROOT/lib/slbmjni.jar" RSTT.SetNodes
I recommend putting these commends in individual, executable csh files. Java errors including Òjava.lang.NoClassDefFoundErrorÓ are typically related to the CLASSPATH.

Best,

Steve Myers, LLNL, October 2012
