var _c_p_p_globals_8h =
[
    [ "ABSTRACT", "_c_p_p_globals_8h.html#afac4c0927892b28c42e3bbb664df5d11", null ],
    [ "byte", "_c_p_p_globals_8h.html#a71809484a26cd96c6abe839a0a8a289d", null ],
    [ "GEOTESS_EXP", "_c_p_p_globals_8h.html#aaee2226d252bf7edddd7cf47cd43e24e", null ],
    [ "GEOTESS_EXP_IMP", "_c_p_p_globals_8h.html#a6d6f429d6fb29ab3d10198fc077ea597", null ],
    [ "LONG_INT", "_c_p_p_globals_8h.html#ad1811715322a090d0de8c9974245038a", null ],
    [ "LONG_INT_F", "_c_p_p_globals_8h.html#aa35bbdbc4daabd6f0106e26c8e5fe81c", null ],
    [ "int64", "_c_p_p_globals_8h.html#aecfc3c54bd29ad5964e1c1c3ccbf89df", null ],
    [ "uByte", "_c_p_p_globals_8h.html#ab596ceaaa7799cfbecde6d4c3332f249", null ],
    [ "EARTH_RAD", "_c_p_p_globals_8h.html#a94e5e0e12061700c2d451aa7f8477ff8", null ],
    [ "NA_VALUE", "_c_p_p_globals_8h.html#abf025b77f3d3df18be862a7a1f43645b", null ]
];