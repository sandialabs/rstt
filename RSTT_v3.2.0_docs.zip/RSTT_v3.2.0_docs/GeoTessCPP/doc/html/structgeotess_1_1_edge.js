var structgeotess_1_1_edge =
[
    [ "cornerj", "structgeotess_1_1_edge.html#a658a1425989082905dea2ad5f2b450f8", null ],
    [ "next", "structgeotess_1_1_edge.html#a4310db218f434d7948ad3293ccb44d37", null ],
    [ "normal", "structgeotess_1_1_edge.html#a3b4894b4dbb880ed89f99bf5863b03d7", null ],
    [ "tLeft", "structgeotess_1_1_edge.html#a0ddff08d84f930e6e79675023d981d67", null ],
    [ "tRight", "structgeotess_1_1_edge.html#a5d81fd97e3302c40bf40ea5ea0806b03", null ],
    [ "vj", "structgeotess_1_1_edge.html#a06e7d7b9c5af3db7f40eaa529c2b8344", null ],
    [ "vk", "structgeotess_1_1_edge.html#a7428313c1b2f90a540f81684518de509", null ]
];