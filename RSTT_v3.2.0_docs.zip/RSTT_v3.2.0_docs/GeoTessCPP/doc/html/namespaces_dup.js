var namespaces_dup =
[
    [ "geotess", "namespacegeotess.html", "namespacegeotess" ]
];