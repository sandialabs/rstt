var classgeotess_1_1_geo_tess_optimization_type =
[
    [ "~GeoTessOptimizationType", "classgeotess_1_1_geo_tess_optimization_type.html#a5a396afe587b3c43af2952c175ac9ee6", null ]
];