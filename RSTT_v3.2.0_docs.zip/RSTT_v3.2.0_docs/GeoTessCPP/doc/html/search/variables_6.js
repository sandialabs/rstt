var searchData=
[
  ['global_1340',['global',['../classgeotess_1_1_geo_tess_polygon.html#ac67562e754079b0896ac1d60d2ccb621',1,'geotess::GeoTessPolygon']]]
];
