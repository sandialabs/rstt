var searchData=
[
  ['long_5fint_1390',['LONG_INT',['../_c_p_p_globals_8h.html#ad1811715322a090d0de8c9974245038a',1,'CPPGlobals.h']]],
  ['long_5fint_5ff_1391',['LONG_INT_F',['../_c_p_p_globals_8h.html#aa35bbdbc4daabd6f0106e26c8e5fe81c',1,'CPPGlobals.h']]]
];
