var searchData=
[
  ['abstract_1386',['ABSTRACT',['../_c_p_p_globals_8h.html#afac4c0927892b28c42e3bbb664df5d11',1,'CPPGlobals.h']]]
];
