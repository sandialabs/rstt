var searchData=
[
  ['int64_1382',['int64',['../_c_p_p_globals_8h.html#aecfc3c54bd29ad5964e1c1c3ccbf89df',1,'CPPGlobals.h']]]
];
