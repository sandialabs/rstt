var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuvw~",
  1: "acegi",
  2: "g",
  3: "acegi",
  4: "abcdefgilmnoprstuvw~",
  5: "abcdefgilmnrstv",
  6: "iu",
  7: "o",
  8: "abgl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "related",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Friends",
  8: "Macros"
};

