var classgeotess_1_1_geo_tess_position_natural_neighbor =
[
    [ "GeoTessPositionNaturalNeighbor", "classgeotess_1_1_geo_tess_position_natural_neighbor.html#aa924b23cdd33ef5875c0a87a157caae7", null ],
    [ "~GeoTessPositionNaturalNeighbor", "classgeotess_1_1_geo_tess_position_natural_neighbor.html#a1ab9dd53b2f78ae4e3a4e8efea46dae7", null ],
    [ "getInterpolatorType", "classgeotess_1_1_geo_tess_position_natural_neighbor.html#a66270654c386783559be16331ff7e7b8", null ],
    [ "getMemory", "classgeotess_1_1_geo_tess_position_natural_neighbor.html#a1c2677d7a48b7b8aeb295981f8be0db7", null ],
    [ "update2D", "classgeotess_1_1_geo_tess_position_natural_neighbor.html#a4a17289a1c9bbbdad1cf7c24298788d0", null ]
];