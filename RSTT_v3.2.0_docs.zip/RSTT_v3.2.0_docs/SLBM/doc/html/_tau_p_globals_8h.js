var _tau_p_globals_8h =
[
    [ "TAUP_EXP", "_tau_p_globals_8h.html#a329fdfcf01551342d7c844af6cb73226", null ],
    [ "TAUP_EXP_IMP", "_tau_p_globals_8h.html#a15ebe8fbe80dd94f43323012f1f3da7c", null ]
];